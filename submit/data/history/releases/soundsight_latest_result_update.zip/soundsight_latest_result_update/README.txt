Software increment for the existing SoundSight_PYNQ_3D_Speaker installation.
See files/document/ps-latest-result.md. No bit/HWH or private profiles included.
Install this companion before running the new LAT1 FPGA bitstream.
Old bitstreams retain their old full-queue behavior.
