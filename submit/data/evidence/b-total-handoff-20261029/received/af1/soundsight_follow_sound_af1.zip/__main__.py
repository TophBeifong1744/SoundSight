"""Install an explicit acoustic-follow CLI; no hardware access or auto-start."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from zipfile import ZipFile

BOARD = 'software/tetra3d/linux/board_3d.py'
ALLOWED = {BOARD, 'software/tetra3d/tests/test_follow_sound.py', 'document/follow-sound-af1.md'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_path(root, name):
    p = Path(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name:
        raise ValueError('Invalid update path')
    target = root/p
    if root not in target.resolve().parents:
        raise ValueError('Path escapes destination: '+name)
    return target


def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.af1-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def install(archive, destination):
    root = Path(destination).resolve()
    if not root.is_dir():
        raise ValueError('Installed 3-D speaker directory does not exist')
    with ZipFile(archive) as z:
        manifest = json.loads(z.read('manifest.json'))
        if set(manifest['files']) != ALLOWED:
            raise ValueError('Unexpected update file set')
        payload = {n: z.read('payload/'+n) for n in ALLOWED}
    for name, data in payload.items():
        if digest(data) != manifest['files'][name]:
            raise ValueError('Payload hash mismatch: '+name)
    # Do all compatibility/conflict checks before creating a backup or writing.
    for name, expected in manifest['base'].items():
        target = safe_path(root, name)
        current = digest(target.read_bytes())
        allowed = {expected}
        if name in payload:
            allowed.add(digest(payload[name]))
        if current not in allowed:
            raise ValueError('Different installed version; preserve it: '+name)
    for name, data in payload.items():
        target = safe_path(root, name)
        if name != BOARD and target.exists() and target.read_bytes() != data:
            raise ValueError('Existing different file preserved: '+name)
    changed = [n for n in sorted(payload) if not (root/n).exists() or (root/n).read_bytes() != payload[n]]
    if not changed:
        print('AF1_ALREADY_INSTALLED=1 HARDWARE_ACTIONS=0', flush=True)
        return None
    backup = Path(tempfile.mkdtemp(prefix='backup_follow_sound_af1_', dir=str(root)))
    existed = []
    for name in changed:
        target = root/name
        if target.exists():
            old = backup/name
            old.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, old)
            existed.append(name)
    (backup/'restore.json').write_text(json.dumps(dict(existed=existed, added=[n for n in changed if n not in existed]), indent=2), encoding='utf-8')
    print('BACKUP_DIR='+str(backup), flush=True)
    written = []
    try:
        for name in changed:
            atomic_write(root/name, payload[name])
            written.append(name)
            if (root/name).read_bytes() != payload[name]:
                raise RuntimeError('Written file verification failed: '+name)
    except BaseException:
        for name in reversed(written):
            if name in existed:
                atomic_write(root/name, (backup/name).read_bytes())
            else:
                (root/name).unlink()
        raise
    print('FOLLOW_SOUND_AF1_INSTALLED=1 DEFAULT_AXES=off HARDWARE_ACTIONS=0', flush=True)
    return backup


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', default='/home/xilinx/SoundSight_PYNQ_3D_Speaker')
    args = parser.parse_args()
    import fcntl
    with open('/tmp/soundsight-ps-owner.lock', 'a') as owner:
        try:
            fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Stop current capture before installing AF1') from None
        install(Path(sys.argv[0]).resolve(), args.destination)


if __name__ == '__main__':
    main()
