"""S3 software-only SD installer; keeps S2 hardware and private configuration."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import zipfile

TARGET = Path('/home/xilinx/SoundSight_PYNQ_3D_Speaker')
FILES = {'software/screen/backend.py', 'software/screen/ui.py',
         'soundsight-panel.sh', 'SCREEN-CONTROL.md'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular(root, name, required=False):
    rel = PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or '\\' in name:
        raise RuntimeError('Invalid package path')
    path = root
    for part in rel.parts:
        path = path / part
        if path.is_symlink():
            raise RuntimeError('Unexpected symlink: ' + str(path))
    if path.exists() and not path.is_file():
        raise RuntimeError('Expected regular file: ' + str(path))
    if required and not path.is_file():
        raise RuntimeError('Required file missing: ' + str(path))
    return path


def save(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(str(path), mode)


def install(archive, target):
    target = Path(target)
    if target.is_symlink() or not target.is_dir():
        raise RuntimeError('Expected existing runtime directory')
    with zipfile.ZipFile(archive) as z:
        manifest = json.loads(z.read('manifest.json'))
        if manifest.get('revision') != 'SCREEN_CONTROL_S3' or set(manifest['files']) != FILES:
            raise RuntimeError('Wrong S3 package')
        payload = {name: z.read(name) for name in sorted(FILES)}
    for name, data in payload.items():
        if digest(data) != manifest['files'][name]:
            raise RuntimeError('Package checksum mismatch: ' + name)
    for name, expected in manifest['dependencies'].items():
        if digest(regular(target, name, True).read_bytes()) != expected:
            raise RuntimeError('Unrecognized runtime/S2 dependency; nothing changed: ' + name)
    for name in FILES:
        path = regular(target, name)
        current = digest(path.read_bytes()) if path.exists() else None
        if current not in (manifest['before'][name], manifest['files'][name]):
            raise RuntimeError('Local change; nothing overwritten: ' + name)
    receipt_path = regular(target, 'SCREEN-INSTALL.json', True)
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    if receipt.get('revision') != 'SCREEN_PS_I2C_S2' or receipt.get('touch_transport') != 'PS_I2C0_EMIO_LINUX':
        raise RuntimeError('Install S2 first')
    if not isinstance(receipt.get('software'), dict) or not isinstance(receipt.get('hardware'), dict):
        raise RuntimeError('Incomplete S2 receipt')
    for name in ('soundsight.bit', 'soundsight.hwh'):
        if receipt['hardware'].get(name) != manifest['dependencies'][name]:
            raise RuntimeError('S2 receipt hardware mismatch')
    # Keep original installed_boot_id and hardware revision; no fake reprogram/reboot.
    receipt['software'].update(manifest['files'])
    receipt['control_revision'] = 'SCREEN_CONTROL_S3'
    payload['SCREEN-INSTALL.json'] = (json.dumps(receipt, indent=2) + '\n').encode()
    payload['SCREEN-CONTROL-INSTALL.json'] = (json.dumps(dict(
        revision='SCREEN_CONTROL_S3', files=manifest['files'],
        hardware_unchanged=True, board_joint_test='NOT_RUN'), indent=2) + '\n').encode()
    originals, modes = {}, {}
    for name in payload:
        path = regular(target, name)
        originals[name] = path.read_bytes() if path.exists() else None
        modes[name] = path.stat().st_mode & 0o777 if path.exists() else 0o644
    backup = Path(tempfile.mkdtemp(prefix='backup_screen_control_s3_', dir=str(target)))
    for name, data in originals.items():
        if data is not None:
            save(backup/name, data, modes[name])
    save(backup/'restore.json', json.dumps(dict(
        present=[n for n, v in originals.items() if v is not None],
        absent=[n for n, v in originals.items() if v is None]), indent=2).encode())
    stage = Path(tempfile.mkdtemp(prefix='.screen-control-stage-', dir=str(target)))
    changed = []
    print('BACKUP_DIR=' + str(backup), flush=True)
    try:
        for name, data in payload.items():
            save(stage/name, data, modes[name])
        for name in payload:
            dest = target/name
            dest.parent.mkdir(parents=True, exist_ok=True)
            os.replace(str(stage/name), str(dest))
            changed.append(name)
        if hasattr(os, 'sync'):
            os.sync()
    except BaseException:
        for name in reversed(changed):
            if originals[name] is None:
                (target/name).unlink()
            else:
                shutil.copy2(str(backup/name), str(target/name))
        if hasattr(os, 'sync'):
            os.sync()
        raise
    finally:
        shutil.rmtree(str(stage))
    print('SCREEN_CONTROL_S3_INSTALLED=1 HARDWARE_ACCESS=0 DEFAULT_AXES=off')
    print('BITSTREAM_UNCHANGED=1 REBOOT_REQUIRED=0 USER_PROFILES_UNCHANGED=1')
    return backup


def main():
    if sys.platform != 'linux' or os.geteuid() != 0:
        raise RuntimeError('Run with sudo python3 on PYNQ')
    import fcntl
    locks = []
    for name in ('/tmp/soundsight-screen-owner.lock', '/tmp/soundsight-ps-owner.lock'):
        owner = open(name, 'a')
        fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locks.append(owner)
    tokens = (b'board_3d.py', b'run_pcm.py', b'run_buffered.py', b'live_speaker.py',
              b'speaker_process.py', b'pipeline_backend', b'software/screen/ui.py',
              b'software/screen/screen_i2c_prepare.py')
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            command = (proc/'cmdline').read_bytes()
        except OSError:
            continue
        if any(token in command for token in tokens):
            raise RuntimeError('Stop screen/runtime before installation; PID=' + proc.name)
    install(Path(sys.argv[0]), TARGET)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('STOP: ' + str(exc), file=sys.stderr)
        sys.exit(1)
