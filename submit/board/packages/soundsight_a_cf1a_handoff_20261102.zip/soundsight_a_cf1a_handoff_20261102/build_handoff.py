"""Bundle the unchanged CF1A release and explicit A handoff material, no private audio."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
CF1A = ROOT.parent/'ss-three-d-coherent-cf1a'
CF1 = ROOT.parent/'ss-three-d-coherent-cf1'
PACKAGE = CF1A/'delivery/soundsight_three_d_coherent_cf1a.zip'
EXPECTED = '5649788d4962df613f25e8060c31a4a8ea9f6543e01355ce667fcf70db2f6698'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, data):
    path = ROOT/name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    entries[name] = data

entries = {name: (ROOT/name).read_bytes() for name in (
    '给A-先读.md', '三维测试指令.md', '测试结果回传模板.md', 'build_handoff.py')}
assert sha(PACKAGE.read_bytes()) == EXPECTED, 'Release changed: review before repackaging'
write('update/'+PACKAGE.name, PACKAGE.read_bytes())
diffs = []
with zipfile.ZipFile(PACKAGE) as new, zipfile.ZipFile(CF1/'delivery/soundsight_three_d_coherent_cf1.zip') as old:
    assert new.testzip() is None and old.testzip() is None
    manifest = json.loads(new.read('manifest.json'))
    for name, checksum in sorted(manifest['files'].items()):
        data, before = new.read(name), old.read(name)
        assert sha(data) == checksum and sha(before) == manifest['before'][name]
        assert data == (CF1A/'runtime'/name).read_bytes()
        if name.endswith('.py'):
            ast.parse(data.decode(), feature_version=(3,8))
        write('source/cf1a/'+name, data)
        write('source/cf1-before/'+name, before)
        diffs.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), data.decode().splitlines(keepends=True),
                                        fromfile='cf1-before/'+name, tofile='cf1a/'+name))
    write('reference/cf1a-manifest.json', new.read('manifest.json'))
    write('source/cf1a-install_update.py', new.read('__main__.py'))
write('source/integration-diff.patch', ''.join(diffs).encode('utf-8'))
write('reference/CF1A-原交付说明.md', (CF1A/'README.md').read_bytes())
for name in ('REPORT.md', 'INDEPENDENT-REVIEW.md', 'release-integrity.json', 'replay.json', 'timing.json',
             'test_online_3d.log', 'test_follow_sound.log', 'test_speaker_follow.log',
             'test_speaker_display.log', 'test_cf1.log', 'test_installer.log'):
    write('evidence/cf1a/'+name, (CF1A/'verification'/name).read_bytes())
for name in ('board-run-1.json', 'board-run-2.json'):
    write('evidence/cf1-board-baseline/'+name, (CF1/'verification'/name).read_bytes())
record = dict(package='soundsight_a_cf1a_handoff_20261102.zip', date='2026-11-02',
              purpose='A installs CF1A and returns 3D board results to user',
              update_sha256=EXPECTED, update_unchanged=True, board_cf1a_test='NOT_RUN',
              full_project=False, raw_audio_included=False, speaker_templates_included=False,
              files={name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(entries.items())})
write('HANDOFF-MANIFEST.json', (json.dumps(record, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
write('SHA256SUMS.txt', ''.join(sha(data)+'  '+name+'\n' for name, data in sorted(entries.items())).encode('utf-8'))
delivery = ROOT/'delivery'
delivery.mkdir(exist_ok=True)
output = delivery/'soundsight_a_cf1a_handoff_20261102.zip'
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(entries.items()):
        z.writestr('soundsight_a_cf1a_handoff_20261102/'+name, data)
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(entries)
    for name, data in entries.items():
        assert z.read('soundsight_a_cf1a_handoff_20261102/'+name) == data
result = dict(status='PASS', archive=str(output), bytes=output.stat().st_size,
              sha256=sha(output.read_bytes()), entries=len(entries), inner_update_sha256=EXPECTED,
              crc=True, all_entries_equal=True, hardware_actions=0)
(delivery/'package-verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
