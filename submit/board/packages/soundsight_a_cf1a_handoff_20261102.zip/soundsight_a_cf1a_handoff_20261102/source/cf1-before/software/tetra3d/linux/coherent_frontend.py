"""CF1: bounded causal PCM spectral frontend; original C geometry and motion gates.

One DMA owner supplies validated immutable packets. No MMIO, files, threads,
device allocation or direction normalization to bypass physical acceptance.
"""
from collections import OrderedDict, deque
from pathlib import Path
import time
import numpy as np

PAIRS = ((0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3))
SCANS = (6, 8, 6, 6, 8, 6)


class CoherentSolver:
    requires_pcm = True

    def __init__(self, native, epoch, hann_path, clock=time.monotonic):
        self.native, self.epoch, self.clock = native, epoch, clock
        self.hann = np.array([int(s, 16) for s in Path(hann_path).read_text().split()], dtype=np.float64)/131072.
        if self.hann.shape != (1024,) or not np.isfinite(self.hann).all():
            raise ValueError('CF1 requires the packaged 1024-point Q17 Hann table')
        self.blocks = OrderedDict()
        self.history = deque(maxlen=16)
        self.last_packet = self.last_sequence = self.last_start = None
        self.source_completed_at = None
        self.capture_started_at = None
        self.stats = dict(revision='CF1', packets=0, solved=0, valid=0, missing_pcm=0,
                          resets=0, clipped_windows=0, max_solve_seconds=0., max_blocks=0)

    def started(self, when):
        if self.last_packet is not None or not np.isfinite(when):
            raise ValueError('CF1 start origin must precede all packets')
        self.capture_started_at = float(when)

    def accept_packet(self, data, meta):
        # The acquisition owner called decode_packet before this method.
        if (len(data) != 8224 or meta['epoch'] != self.epoch or
                meta['sample_count'] != 512 or meta['sample_start'] != meta['block_seq']*512 or
                self.last_packet is not None and meta['block_seq'] != self.last_packet+1):
            raise ValueError('CF1 PCM session/continuity mismatch')
        self.last_packet = meta['block_seq']
        self.blocks[meta['sample_start']] = (data[32:], self.clock(), bool(meta['clipped']))
        while len(self.blocks) > 64:
            self.blocks.popitem(last=False)
        self.stats['packets'] += 1
        self.stats['max_blocks'] = max(self.stats['max_blocks'], len(self.blocks))

    def reset_history(self):
        self.history.clear()
        self.last_sequence = self.last_start = None
        self.stats['resets'] += 1

    def has_window(self, frame):
        a = frame.get('audio', {})
        start = a.get('sample_start')
        return bool(a.get('valid') and a.get('epoch') == self.epoch and
                    start in self.blocks and start+512 in self.blocks)

    def invalid(self, frame, reason):
        self.reset_history()
        result = self.native.solve(dict(frame, words=[v for i in range(6)
            for v in ((i << 8) | (2 << 24) | (6 << 28), 0, 0, 0, 0)]))
        result.update(direction_valid=0, azimuth_valid=0, elevation_valid=0,
                      frontend='CF1', cf1_reset=reason, source_completed_at=self.source_completed_at)
        return result

    def solve(self, frame):
        began = self.clock()
        self.source_completed_at = None
        a = frame.get('audio', {})
        if (not a.get('valid') or a.get('epoch') != self.epoch or a.get('sample_count') != 1024 or
                type(a.get('sample_start')) is not int or a['sample_start'] % 512):
            return self.invalid(frame, 'pcm_frame_unavailable')
        start = a['sample_start']
        blocks = [self.blocks.get(start), self.blocks.get(start+512)]
        if any(b is None for b in blocks):
            self.stats['missing_pcm'] += 1
            return self.invalid(frame, 'pcm_window_not_received')
        self.source_completed_at = blocks[1][1]
        if self.capture_started_at is not None:
            # START is issued after this host origin. The predicted end is an
            # earlier bound, so queued DMA cannot make old samples look fresh.
            self.source_completed_at = min(self.source_completed_at,
                self.capture_started_at+(start+1024)/48000.)
        if any(b[2] for b in blocks):
            self.stats['clipped_windows'] += 1
            return self.invalid(frame, 'pcm_clipped')
        if self.clock()-self.source_completed_at >= .75:
            return self.invalid(frame, 'pcm_window_stale')
        if (self.last_sequence is not None and
                (frame['sequence'] != (self.last_sequence+1) & 0xffffffff or start != self.last_start+512)):
            self.reset_history()
        self.last_sequence, self.last_start = frame['sequence'], start
        pcm = np.frombuffer(blocks[0][0]+blocks[1][0], dtype='<i4').reshape(1024, 4)
        ft = np.fft.rfft(np.rint(pcm*self.hann[:, None]), axis=0)
        cross = np.array([ft[:, x]*ft[:, y].conj() for x, y in PAIRS])
        power = np.abs(cross[:, 7:86])**2
        mask = np.zeros(cross.shape, dtype=bool)
        mask[:, 7:86] = (power > 0) & (2500*power >= power.max(axis=1, keepdims=True))
        phase = np.zeros(cross.shape, dtype=np.complex128)
        phase[mask] = cross[mask]/np.abs(cross[mask])
        self.history.append((mask, phase))
        hits = np.sum([v[0] for v in self.history], axis=0)
        phase_sum = np.sum([v[1] for v in self.history], axis=0)
        concentration = np.abs(phase_sum)/np.maximum(hits, 1)
        keep = (hits >= 4) & (concentration >= .7)
        spectrum = phase_sum/len(self.history)*concentration**2
        spectrum[~keep] = 0
        counts = keep.sum(axis=1)
        corr = np.fft.irfft(spectrum, n=1024, axis=1)
        words = []
        for i in range(6):
            if counts[i] < 12:
                words.extend([(i << 8) | (2 << 24) | (6 << 28), 0, 0, 0, 0])
                continue
            lags = np.arange(-SCANS[i], SCANS[i]+1)
            lag = int(lags[np.argmax(corr[i, lags % 1024])])
            values = np.rint(corr[i, np.array([lag, lag-1, lag+1]) % 1024]*2**24).astype(np.int64)
            word = (lag & 255) | (i << 8) | (1 << 11) | (1 << 13) | (int(counts[i]) << 16) | (1 << 24) | (1 << 28)
            words.extend([word]+[int(v) & 0xffffffff for v in values]+[0])
        # Only the numerical bridge receives these software features. The original
        # hardware snapshot, sequence, raw admission bits and CONSUME stay intact.
        result = self.native.solve(dict(frame, words=words))
        if result['valid_pairs'] < 4:
            result.update(direction_valid=0, azimuth_valid=0, elevation_valid=0, reason=1)
        result.update(frontend='CF1', history_frames=len(self.history), source_completed_at=self.source_completed_at)
        self.stats['solved'] += 1
        self.stats['valid'] += int(bool(result['direction_valid']))
        self.stats['max_solve_seconds'] = max(self.stats['max_solve_seconds'], self.clock()-began)
        return result

    def summary(self):
        return dict(self.stats, buffered_blocks=len(self.blocks), history_frames=len(self.history),
                    audio_support_ms=181.333333, nominal_history_center_extra_ms=80,
                    freshness_basis='conservative_start_plus_sample_end',
                    physical_gates_unchanged=True, board_latency_measured=False)
