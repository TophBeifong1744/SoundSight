# 三维定位 CF1 更新

本包接入相位一致性筛选和16帧频谱积累。普通声音模式、声纹模式及S3屏幕的START入口共用新定位前端。普通模式不加载声纹模型；声纹模式保持原目标、门限和score_ttl_v2许可。原始PCM录音命令保持不变。

修改的是PS软件，不含新位流，不改舵机引脚、机械标定、屏幕驱动、音量/滤波配置和声纹资料。默认仍不开轴；需要在命令或屏幕中明确选择。原硬件对动作的原始麦克风对数量检查保留，所以“软件有方向”不保证每一帧都能提交动作。

用户接受本轮以能够正常输出方向为目标；俯仰数值仍未标定，不能作为精确测角验收。静止背面记录的约18度俯仰也可能包含现场高度差，现有证据不能定责。

## 安装

先在屏幕点STOP并EXIT，或串口发Ctrl+C（HEX 03），等待当前会话结束。把soundsight_three_d_coherent_cf1.zip放到SD启动分区：

```bash
sudo python3 /boot/soundsight_three_d_coherent_cf1.zip
```

应出现THREE_D_CF1_INSTALLED=1。安装器自动备份，检查S2硬件/S3软件及依赖，遇到未知修改则停止。安装不会改写私人资料或进行硬件操作，本次软件更新不要求额外重启。

```bash
cd /home/xilinx/SoundSight_PYNQ_3D_Speaker
```

```bash
sudo env PYNQ_PYTHON=/usr/local/share/pynq-venv/bin/python3 XILINX_XRT=/usr sh soundsight-3d.sh check
```

如果本次刚开机、还没prepare，再执行下面这一条；已prepare的同次开机不必重做：

```bash
sudo env PYNQ_PYTHON=/usr/local/share/pynq-venv/bin/python3 XILINX_XRT=/usr sh soundsight-3d.sh prepare
```

## 一轮板端确认

下面为30秒自动停止的普通声音三维测试。保持原有已验证机械限位，明确开启双轴；持续说话或播放测试音，观察角度和转向。不要同时运行屏幕/第二个采集命令。

```bash
sudo env PYTHONUNBUFFERED=1 PYNQ_PYTHON=/usr/local/share/pynq-venv/bin/python3 XILINX_XRT=/usr sh soundsight-3d.sh follow-sound --axes both --seconds 30
```

应先看到THREE_D_FRONTEND=CF1、SPEAKER=DISABLED，随后FRAME/角度输出，结束出现THREE_D_STOPPED SUMMARY=...。如果只看方向不转动，将both换为off。这次直接使用现有录音研究选出的代码，不需先重做整套声学实验。

```bash
sudo env PYNQ_PYTHON=/usr/local/share/pynq-venv/bin/python3 XILINX_XRT=/usr sh soundsight-3d.sh status
```

请保留本轮串口输出及SUMMARY文件。板端检查关注：结果PASS、无新增采集fault/drops、正常STOP、DMA已停、CF1有有效窗口、最终滤波有输出。报告中的max_solve_seconds与max_service_gap_seconds用于判断PYNQ算力是否足够。若报故障，不反复prepare清状态，先保存日志。

## 屏幕与声纹

S3面板用原命令启动，普通和声纹模式都会使用CF1。新开机且触摸I2C尚未启用时，先执行已有I2C准备命令：

```bash
sudo env PYNQ_PYTHON=/usr/local/share/pynq-venv/bin/python3 sh soundsight-screen-i2c.sh apply
```

```bash
sudo env PYNQ_PYTHON=/usr/local/share/pynq-venv/bin/python3 sh soundsight-panel.sh
```

屏幕START/STOP、模式及轴选择保持原用法，P02资料不会被本包替换。不要在串口采集中同时打开面板。软件已接合不代表本候选的实麦实时性、屏幕联合运行和长稳已经验收。

## 回退

先停止并退出运行。用安装时显示的准确BACKUP_DIR替换下面占位内容：

```bash
sudo python3 /boot/soundsight_three_d_coherent_cf1.zip --restore /home/xilinx/SoundSight_PYNQ_3D_Speaker/backup_three_d_cf1_实际后缀
```

回退前检查当前文件仍为本次安装版本，保留当前版本副本，再恢复原文件及软件校验记录；不更改用户配置。不要输入字面上的“实际后缀”。

## 实现边界

采集仍由单一硬件所有者负责。完成包复制后先重挂DMA；按同一epoch/sample_start精确匹配两包1024点。PL快照稍早于DMA完成时最多等待50ms并继续服务DMA；不拿最新音频替代指定窗口。历史最多16帧，PCM缓存最多64包；断帧、缺失、削顶或陈旧窗口不会发布方向。STOP后不启动新声纹或新动作。

16帧支持约181ms音频，名义历史中心增加80ms；实际响应依内容改变。CF1实板运算时间尚未测量。原C几何解算、最终角度滤波、低音量撤销、原始硬件动作门禁和声纹许可均保留。
