#include "xil_printf.h"
#include "sleep.h"

int main(void)
{
    xil_printf("PS application running.\r\n");

    while (1) {
        sleep(1);
    }

    return 0;
}