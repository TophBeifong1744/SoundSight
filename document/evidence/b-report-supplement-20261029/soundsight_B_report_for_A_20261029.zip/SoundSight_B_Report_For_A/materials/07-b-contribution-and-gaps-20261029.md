> A交接版：从ZIP完整解压后阅读；本稿链接可离线打开。历史运行包未附，见根目录START-HERE。

# B成员工作梳理与比赛材料补充稿

整理日期：2026-10-29。用途：供A补充比赛报告、分工说明、实验结果和交付清单。本稿只整理已有源码与证据；没有重新运行算法、构建固件、操作板卡或公开发布。

**B可以补足的是算法实现、软件迁移、性能对照、板测诊断与交接材料。现有证据仍不足以补齐“三维整机实测通过”和“人物跟随演示完成”。** PR #24 已合入 main 的是比赛资料，不等于全部B算法、模型资产和最终运行工程均已合入。

## 1. 对照A截图：现在能补哪些缺项

| A列出的缺项 | B已有可补材料 | 补入后仍缺什么 |
|---|---|---|
| 完整三维交付包 | 三维C/Python源码、构建入口、DAS与六项优化说明；声纹CP1/VF1私有交接包；AF1增量包、安装/回退证据；A联合包的接入检查记录 | A统一最终候选版本，确认实际采用哪些B模块，配套bit/HWH、环境依赖和模型；真实P02模板需保留/导出自原板，B交接包不含该真实模板。不能将几个包简单拼接后称整机验收版 |
| 三维实测记录 | 三维合成数值对照、PC DAS及软件性能；联合包prepare成功；AF1 ARM构建及离线回归；垂直手动命令被接受但无运动的失败记录 | 实测阵列坐标/通道、参考方位与俯仰、误差/有效率/响应时间、连续运行恢复、真实DAS拾音、身份与方向关联、机构响应。二维实麦和ARM离线不能替代这些数据 |
| 整机照片和运行截图 | 已有串口/测试输出可作软件验证配图 | 四麦布局、接线、供电、机构全貌及最终版本界面，需真实拍摄；日志不能替代照片 |
| 演示视频 | 可以提供三维/声纹功能范围、演示条件和失败边界的文字依据 | 与最终候选一致、3分钟内的真实演示尚不能由本批记录补齐；本轮不录制、不驱动硬件 |
| 签署授权书 | 本稿可供填写B职责，第三方来源说明可辅助归属核对 | 官方模板、实际签署及PDF仍需完成 |
| AI协作原始选编 | 可选三维桥接、DAS过期方向修正、CP1/VF1优化及数值拒绝、AF1与无运动诊断等案例；源码差异和测试结果均可追溯 | 需从真实聊天中选出对应提示词、回答、纠错原文。报告摘要/交接提示词不能冒充原始对话，本稿未编造对话 |
| 报告定稿 | 可直接补“B分工”“算法实现”“软件性能实验”“失败分析与局限”；下文提供可用正文 | A将内容并入22页草稿，并结合最终实测定稿；本轮没有修改该草稿或声称其已入仓 |
| 同功能PL资源优化 | B有CPU耗时、Python块分配、模型计算布局对照 | 这些不属于LUT/FF/BRAM/DSP优化率；没有同功能、同条件的PL成对报告，继续保留A的分阶段资源表，不补造优化率 |

截图另列的照片匿名/条码处理、报名字段、截止时间和入围后英文海报，不由算法结果自动解决。本轮没有核验赛事官网要求。

## 2. “我做了什么、怎么做、效果、未完成项”

### 2.1 早期STM32 S1/S2与本板验证

**做了什么。** B完成冻结接口下的S1方向求解、S2通用驱动、STM32F407板级适配及统一自检。它是项目早期技术路线成果，不能写成当前PYNQ最终方案仍必须通过STM32计算。

**实现方法。** S1用C99实现有符号字段解码、相关峰插值、质量与时差资格检查、最小二乘方向求解、残差/范数拒绝、整数CORDIC和水平映射；拒绝时清除旧输出，BIST不产生动作。S2按冻结SPI协议处理探测、启动、锁定快照、读取六对特征、RELEASE/CONSUME、停止与故障恢复，绑定板级SPI/定时/IRQ接口。共享ABI统一维护，FPGA实现由A侧负责。

**效果与证据。**

- PC：S1 **4705项断言、0失败**；S2 **15980项断言、0失败**，含双BIST各40事务和160组逐事务故障注入。这是模型验证数量，不是板测次数。
- 构建：ARM Compiler 5重建0错误、0警告，生成固件。
- 真实STM32本板：2026-10-17串口 **11通过、0失败、11跳过**；两组S1求解末次耗时约685/729μs。该记录验证MCU本地执行，跳过的SPI跨板和机械项不能计为通过。
- 后续诊断：本板曾为13/0/11；G02-R01出现一次跨板32/0/4正常对照，但此前多轮有pair错配、prepare/格式故障，不能仅凭正常轮认定根因修复。本稿保留这段演进，避免引用旧README的“跨板未测”作为截至29日的全部事实。

**未完成。** 旧路线的长期跨板可靠性、物理SPI波形根因闭合和连续动作闭环未由这些记录完成；后续主线已转PL+PS，不恢复历史待办。

源码：[S1求解](../references/SoundSight-stm32/software/common/s1/doa_solver.c)、[S2驱动](../references/SoundSight-stm32/software/stm32/src/fpga_link.c)、[板级实现](../references/SoundSight-stm32/software/stm32/keil/soundsight_f407/User/soundsight_board.c)。证据：[S1报告](../references/SoundSight-stm32/software/common/s1/README.md)、[S1日志](../references/SoundSight-stm32/document/evidence/stm32-workspace-20261018/s1.log)、[S2日志](../references/SoundSight-stm32/document/evidence/stm32-workspace-20261018/s2.log)、[构建日志](../references/SoundSight-stm32/document/evidence/stm32-workspace-20261018/keil-rebuild.log)、[本板串口原文](../references/SoundSight-stm32/document/evidence/stm32-board-20261017/board-only-user-uart.log)、[正常对照](../references/SoundSight-stm32/document/evidence/stm32-p4-acquire-diag-20261019/G02-R01.md)。

### 2.2 二维PYNQ算法迁移与实麦板测

**做了什么。** 将S1以C共享库/Python桥接形式用于Linux，完成数值一致性检查；接续A交付的二维PYNQ工程开展无舵机测试，并修改PS日志存储路径。

**实现方法。** 直接C结果与实际Python调用对照；针对逐条同步存盘引起的积压，仅修改`ram_queue.py`与`run_buffered.py`，采用最多8条/等待最多50ms的批量同步。整批落盘成功才移除RAM副本；容量64、高水位48与保护停止保留；提前退出返回不完整状态。

**效果与证据。** PC完成S1 4705断言、157组接口对照、6组非法输入检查。存储修正64项PC测试通过；确定性慢盘模型由60条触发高水位变为240条完成，但不是板端提速比例。真实PYNQ记录如下：

| 现场项目 | 已有结果 | 能说明什么 |
|---|---|---|
| PL→PS双BIST | 通过/拒绝数值符合预期 | 硬件数据与软件计算的接口对照 |
| 原版1000帧有声 | 1000主帧+1尾帧连续、零丢帧，50个窗口有效 | 本轮真实采集及有效输出；没有参考角精度结论 |
| 原版1000帧安静 | 1000主帧+1尾帧连续、零丢帧、零有效输出 | 该环境的静音筛选行为，环境含电脑风扇 |
| 原版长轮 | 2314/3000帧因高水位停止 | 播放/暂停已做，用户确认没有恢复播放 |
| 批量修正ARM离线 | 6+24项OK | 板上软件模型回归，不是30项实际声学测试 |
| 批量修正真实SD采集 | 2831/3000帧高水位停止；已存帧连续、fault/drop为0；本轮零有效方向 | 存储修正没有解决实际长采集积压；不能用2831与2314直接计算提速 |

**未完成。** 最后tmpfs对照缺结束结果；完整播放/暂停/恢复、多参考角、长期运行未验收。不能把“方向有效率”当“定位准确率”。

源码：[二维共享库桥](../references/SoundSight-b-algorithm/software/ps/ss_solver_bridge.c)、[批量队列](../references/SoundSight-pynq-board-2d/software/ps/ram_queue.py)、[运行入口](../references/SoundSight-pynq-board-2d/software/ps/run_buffered.py)。证据：[迁移PC结果留存](../references/SoundSight-speaker-b/document/evidence/ps-solver-migration-20261020/PC-RESULT.json)、[A接续入口](../references/SoundSight-pynq-board-2d/START-HERE-A.md)、[PC存储报告](../references/SoundSight-pynq-board-2d/SD-BATCH-REPORT.md)、[ARM原始安装回传](../references/SoundSight-pynq-board-2d/evidence/sd-batch-arm-20261022/install-and-tests-uart.txt)、[现场数值转录](../references/SoundSight-pynq-board-2d/evidence/board-summary-20261022.md)。转录不是完整板端JSONL。

### 2.3 正四面体三维方向算法与Linux迁移

**做了什么。** B完成三维C模块及几何/软件双轴数学模块，并将8份原C/H无改动迁入独立`software/tetra3d`，增加共享库桥、Python接口、JSONL回放及验证，保留二维主线。

**实现方法。** 四麦形成六对时差，利用阵列几何建立远场方程`A·u≈τ`，求方位角/俯仰角；检查几何秩和条件数、相关峰质量、时差窗口、拟合残差与向量模长；极点保留空间方向而将方位角标无效。标称40mm正四面体不等于实测坐标。输出是方向，不是三维坐标或距离。

**效果。** PC直接C/Python数值对照154组、非法输入17组、几何15组、CLI 4类通过；原C回归2110/2378/92270断言通过。合成45°/30°输入输出约45.000854°/29.999487°；PC调用中位11μs含桥接等开销。这两项不能标成实物角度精度或Cortex-A9实时耗时。

**未完成。** 实测阵列尺寸/通道/lag符号、多位置声学精度及目标板上的该版本性能。29日A联合包的ARM构建通过是另一组版本/测试事实，不追认所有B独立模块已板测。

源码：[三维求解](../references/SoundSight-b-algorithm/software/tetra3d/core/doa_solver_3d.c)、[几何](../references/SoundSight-b-algorithm/software/tetra3d/core/doa_geometry.c)、[桥接](../references/SoundSight-b-algorithm/software/tetra3d/linux/ss_solver_3d_bridge.c)。证据：[原迁移报告](../references/SoundSight-b-algorithm/document/evidence/ps-tetra3d-migration-20261021/REPORT.md)、[完整PC结果](../references/SoundSight-b-algorithm/document/evidence/ps-tetra3d-migration-20261021/PC-RESULT.json)、[公开E17](records/E17/README.md)。

### 2.4 三维DAS定向拾音

**做了什么。** 复用既有四路动态DAS核心，增加三维几何与求解方向到延时的适配、连续PCM块检查、方向切换与离线WAV输出。

**实现方法。** 相对CH0计算`d_i=fs/c·dot(r_i-r_0,u)`，量化为Q12；四路线性分数延时后等权平均。方向切换淡变，到期退回校准后的单麦，保留8点固定延迟和尾部。使用与定位相同的几何和延迟约定。

**效果。** PC 16项测试通过；70方向1kHz解析声场最大归一化RMS误差0.00106672；实际C求解器8方向接合通过；一个独立白噪声合成场景改善7.2745dB，但包含插值滤波作用，不是实物降噪增益。

**未完成。** 实际同步四路PCM与定位源时间关联、目标ARM吞吐、真实录音对照和听音验收。没有证据证明DAS已接入最终声纹输入；现有声纹前端使用mic0。不能写成说话人分离、MVDR或混响消除。

源码：[DAS适配](../references/SoundSight-b-algorithm/software/tetra3d/das/das_3d.py)、[DAS核心](../references/SoundSight-b-algorithm/software/tetra3d/das/dynamic_das.py)。证据：[DAS方法与实验](../references/SoundSight-b-algorithm/software/tetra3d/das/README.md)。

### 2.5 六项三维软件优化与模块接合

| 优化 | B实现的方法 | 结论边界 |
|---|---|---|
| 方向稳定 | 单位向量筛选、平滑、死区、有界HOLD、候选重捕获 | HOLD不刷新原观测期限；合成方向RMS 2.722807°→0.898019°，不是实物精度 |
| 质量加权 | 有界权重、默认关闭，保留全部合格对未加权残差 | 一个坏对合成例误差4.049°→1.747°，不推广为普遍改善 |
| DAS计算/分配 | 17槽环缓冲、预分配输出、关闭未使用trace | PC 48000点耗时0.176659→0.113945秒，下降35.50% |
| 通道校准接口 | 定位与DAS共用延迟约定，DAS支持增益 | 接口实现不等于实物已标定 |
| 几何/掩码缓存 | 实例独立缓存几何与64种有效对组合，版本化参数 | 默认结果与旧版一致，保留兼容接口 |
| 纯软件双轴 | 安装旋转、极点迟滞、限速、限位、到期处理 | 输出软件设定值，默认禁止输出，不属于A的PWM硬件实现 |

进一步实现`TetraPipeline`，统一求解→方向滤波→可选DAS/软件轴及校准；依据真实源采样时间判断过期，故障/BIST/STOP清除旧方向。当时交付是可导入模块，没有在线运行入口。

PC累计**86项不同Python测试**通过；后续重复回归不重复累计。8192点DAS块的tracemalloc峰值2616168→99820字节，下降96.18%，只是Python块分配指标，不是整机或进程RSS下降。

源码：[统一管线](../references/SoundSight-b-algorithm/software/tetra3d/linux/pipeline_3d.py)、[配套接合说明](../references/SoundSight-b-algorithm/software/tetra3d/INTEGRATION.md)。证据：[完整报告](../references/SoundSight-b-algorithm/document/evidence/tetra3d-optimizations-20261025/REPORT.md)、[模块测试日志](../references/SoundSight-b-algorithm/document/evidence/tetra3d-optimizations-20261025/module-integration.log)、[公开E18](records/E18/README.md)。

### 2.6 声纹迁移、流式前端与目标登记

**做了什么。** B开展ECAPA/CAM++的ARM部署对照，完成C原生后端、PCM转换/降采样、Silero VAD、Mel特征、滑窗缓存、模板余弦评分、采集与推理调度和目标配置工具，并建立离线/实麦计时证据。

**实现方法。** 目标环境为PYNQ 2.7、ARMv7 32位、Python 3.8.2、ORT 1.17.3。声纹使用mic0；61抽头FIR将48kHz转16kHz，25ms分析窗、10ms步进、80维Mel，提取192维嵌入并与登记模板比较。FIR/VAD状态连续保存，新Mel帧只算一次；只保留一个执行任务和最新待算任务。rx3将DMA接收与算法分离到不同Python解释器，通过Unix SEQPACKET和32包信用限制积压。PL连续PCM导出及其硬件时基由A侧提供。

**效果。** 原ARM核心实验从ECAPA约9.064秒转到CAM++双线程约3.165秒（同一3.104秒源语音，但模型输入帧数不同、每组仅2次，不能作为严格同张量提速率）。opt1通过功率谱复用、跳过零Mel权重等优化，使两段各10.912秒输入的平均前端处理耗时7.333079→4.359630秒，下降40.55%；声纹推理步骤几乎未变。均为ARM离线结果。

P02用三段本人历史录音登记，独立于原P01配置；板端开发对照中，全语音本人分数0.849831～0.873486、他人0.410384～0.472553。历史开发样本存在分数间隔，但没有独立准确率/FAR/FRR结论；P02保持score-only，未完成识别门限标定。

**未完成。** 正常音量独立数据验证、识别门限、持续实麦时效、同一人的身份和正确角度关联。全网INT8数值检查失败、短窗误拒等失败也应保留，不仅展示成功候选。

源码：[C后端](../references/SoundSight-speaker-b/software/ps/speaker_core/pipeline_backend.c)、[流式前端](../references/SoundSight-speaker-b/software/ps/speaker_core/stream_frontend.h)、[实时软件](../references/SoundSight-speaker-b/software/ps/live_speaker.py)。证据：[设计](01-design.md)、[早期迭代](02-iterations.md)、[opt1原始结构化回传](records/E05/board-opt1-bench.json)、[P02开发分数](records/E19/development-score-ranges.json)。

### 2.7 声纹计算优化与真实采集诊断

| 候选 | 实现方法 | 已测效果 | 未完成/未采用原因 |
|---|---|---|---|
| RX4 | S24符号扩展改字节校验，空轮询4次MMIO读减为1次，经映射检查后标量读 | ARM纯内存3000包校验CPU 7.608935→0.326382秒，下降95.71%；真实实麦epoch32为938包完整 | 实麦三次推理3.044/2.951/3.013秒均过期；95.71%只属于校验模块 |
| MP1 | 只启用ORT memory pattern，与同编译器重建版对照 | ARM一秒窗1.083055→1.075881秒，下降0.66% | CPU无下降、RSS增加，聚合小差异不能认定显著收益 |
| FS1 / CC1 | FS1固定98帧且保留算术；CC1尝试上下文改写 | FS1 ARM独立约下降0.0077%，并发慢约2.04% | 无实用加速；CC1匹配ORT1.17.3时超数值门限 |
| CP1 | 55处1×1投影改常量右矩阵MatMul，52处CAM gate使用tile8，权重值保留；仅98帧 | ARM独立1.076580→0.917114秒，下降14.81%；节拍前端并发1.558548→1.311640秒，下降15.84%；向量/P02分数逐位一致 | 未达当轮两项20%预设门限；不包含真实DMA采集 |
| VF1 / CP2 | VF1专门展开固定16kHz/固定形状的7个VAD分支；CP2尝试局部卷积改写 | ARM前端4.068824→3.859707秒，下降5.14%；同轮原组合1.583233、CP1 1.322913、CP1+VF1 1.296293秒，组合下降18.12%、对CP1增量2.01%；360块概率/256状态及相关数值检查逐位一致 | VF1未达前端20%/组合20%/增量5%门限；CP2超数值门限；仍不是实麦端到端结果 |

CP1/VF1当轮正式状态为`NUMERIC_PASS_NO_ADOPTION`。随后用户授权将两者打包给A接入，是后续接合决定，不能改写原门限结果。29日联合包模型校验/P02导入成功，也不等于已经完成优化后的联合实麦验收。不同轮次百分比不能相加或相乘；VF1组合18.12%只与该轮原组合比较。

原实麦与离线对照证明了并发负担的重要性：同窗离线约1.06秒且分数一致，实际持续采集时仍约3秒。提高推理优先级的nice0试验只收到691/938包并出现fault8/drop1，未采用。不能靠丢采集或放宽有效期解释成计算优化成功。

源码：[RX4收包](../references/SoundSight-speaker-b/software/ps/pcm_capture.py)、[CP1模型转换](../references/SoundSight-speaker-b/tools/packed_cam_model.py)、[VF1模型转换](../references/SoundSight-speaker-b/tools/vad_fixed_model.py)、[VF1对照工具](../references/SoundSight-speaker-b/tools/vad_frontend_opt.py)。证据：[RX4实麦result](../references/SoundSight-speaker-b/document/evidence/p02-compute-opt-20261027/epoch32-rx4/result.json)、[CP1 ARM汇总](../references/SoundSight-speaker-b/document/evidence/p02-packed-cam-20261028/board-cp1/summary.json)、[VF1终端原回传](../references/SoundSight-speaker-b/document/evidence/p02-vad-frontend-20261028/board-vf1/terminal.txt)、[VF1汇总](../references/SoundSight-speaker-b/document/evidence/p02-vad-frontend-20261028/board-vf1/summary.json)、[公开指标表](metrics.csv)。部分轮次只有终端/聚合回传，缺逐样本文件，不能据此补做统计显著性结论。

### 2.8 AF1无声纹三维入口、板端检查与故障交接

**做了什么。** 在A三维+声纹联合包上新增显式`follow-sound`入口，复用A已有三维runtime和客户端；默认axes off。原run开轴仍走声纹许可，STOP、限位、租约及位流保持原实现。B只改入口产品文件并增加测试/说明，不能把整个三维控制运行时归入AF1原创。

**效果。** PC新增7项入口+原21项三维+6项安装器测试通过；103个原文件中102个保持，唯一产品变化为入口。旧声纹联合回归在Windows因缺`resource`未执行，不计通过。用户板端随后完成两个C库原生构建及21+7项离线测试，`THREE_D_OFFLINE_OK=1 HARDWARE_ACTIONS=0`；这可以写“ARM离线通过”，不能写“声音跟随实测通过”。

**真实硬件记录。** prepare成功，约100MHz、fault=0、drops=0；水平迁入旧配置，垂直只有临时试探配置。两次原manual路径分别发110°、115°各3秒，各30次提交成功、停止确认成功，用户均观察无可见运动；该过程未启动音频。代码每次核读LAST_TARGET和have_command，支持命令被控制寄存器接受；没有PWM实测、机械位置反馈或唯一根因。

**未完成。** A接续核查W15到舵机端波形、连接/共地/带载供电及机构。110°约1500μs、115°约1545μs是代码预测，不是已测波形；临时零位/方向/范围不作标定结果。尚未完成AF1真实声音采集跟随、三维闭环或声纹联合跟随。本轮仅整理这一交接，不执行其中排查命令。

源码：[AF1准确差异](../references/SoundSight-speaker-b/document/evidence/follow-sound-af1-20261029/board_3d.diff)、[AF1入口](../references/SoundSight-speaker-b/work/acoustic-follow-af1/software/tetra3d/linux/board_3d.py)。证据：[AF1报告](../references/SoundSight-speaker-b/document/evidence/follow-sound-af1-20261029/REPORT.md)、[人工操作结果转录](../references/SoundSight-speaker-b/document/handoff-a-vertical-no-motion-20261029/manual-observations.txt)、[prepare/status原文](../references/SoundSight-speaker-b/document/handoff-a-vertical-no-motion-20261029/prepare-status-original.txt)、[给A的完整交接](../references/SoundSight-speaker-b/document/handoff-a-vertical-no-motion-20261029/START-HERE.md)。手动结果文件明确为聊天转录，不是连续UART原始日志。

## 3. 贡献归属：报告应怎么署名

| 归属 | 可写内容 | 不应据为己有的内容 |
|---|---|---|
| B | S1/S2与板级软件；二维算法迁移、指定存储修正及板测分析；三维方向/DAS/六项软件优化；声纹ARM适配、流式计算与候选优化、登记和诊断；AF1入口和交接资料 | 不称原创CAM++/Silero；不把A的RTL、连续PCM硬件、双轴PWM和联合运行时计为B独立实现 |
| A | FPGA采集与相关运算、寄存器/保护、连续PCM硬件导出、当前三维采集/双轴提交与联合系统接合；维护许可保持策略及后续机械问题定位 | B的CP1/VF1提速不能归为PL新增加速；调整许可保持时间不是模型算力提升 |
| 第三方 | ECAPA、CAM++/3D-Speaker、Silero及ONNX Runtime等模型/运行时；PYNQ及厂商工具/IP | 模型结构和已有训练权重不是团队原创；算法工程改写不等于重新训练原创模型 |
| 现场执行者/用户 | 下载、接线、录音、现场命令、观察与仪器操作，以日志和记录署名 | AI整理、分析和生成代码不能写成AI亲自完成硬件测量 |

常见的最小二乘、CORDIC、DAS属于已有方法。B的可说明贡献是面向本项目的实现、迁移、约束处理、兼容优化与验证，而非发明这些数学算法。早期C负责PYNQ应用的分工是历史安排，不宜把现有所有PS代码均归B；本稿仅按有明确修改证据的部分归属。

第三方许可/来源见[声纹模型许可目录](../references/SoundSight-speaker-b/software/ps/speaker_core/licenses/)。公开资料不含私人录音、登记模板和完整模型资产；最终交付按现有私下交接和许可边界处理。

## 4. 可直接给A使用的报告正文

> 成员B主要负责嵌入式算法和软件实现、平台迁移及验证。早期完成STM32侧S1方向求解、S2通信驱动和本板自检，并在转向PYNQ后完成C算法共享库接口与数值对照；针对二维板测中的日志积压问题实现批量保存和故障统计。三维部分实现正四面体四麦的方位角/俯仰角求解、DAS定向拾音，以及方向平滑、质量加权、通道校准接口、缓存和纯软件双轴策略，并形成可导入的统一处理模块。声纹部分基于第三方CAM++和Silero模型完成ARM部署、连续前端、目标登记、采集调度与计算优化，保留数值等价检查和失败候选。后续增加AF1无声纹三维入口，并整理板端检查及垂直轴无运动问题的交接证据。
>
> 实验按验证环境分别报告：S1/S2在PC模型中通过4705/15980项断言；三维DAS优化在指定PC基准中使处理耗时下降35.50%、块分配峰值下降96.18%；声纹CP1+VF1在ARM离线节拍并发实验中，相对同轮原组合耗时下降18.12%，但未达到原定性能门限，不能据此声称实时跟随达标。真实二维采集已有千帧记录，长采集仍出现存储高水位；AF1板端构建和离线回归通过，垂直110°/115°手动命令被接受但均无可见运动。三维声学精度、身份与方向关联及机械闭环仍待最终现场验证。

建议A将这两段放入“成员分工/实现工作”和“实验结果/局限”，再从第2节选取适量方法和数据。无需把所有历史迭代塞入正文；失败、版本和原件留在附录索引。

## 5. 资料入口、版本与本轮交付范围

- 已公开报告：[PR #24](https://github.com/TophBeifong1744/SoundSight/pull/24)，合并提交`e6d28f47eec1bc8b821e5002663fe90ca50c7990`；原[B算法索引](06-b-algorithms.md)、[源码摘录](03-code-highlights.md)、[来源表](source-map.json)、[指标CSV](metrics.csv)已随该批资料合并。本稿是29日新增本地整理，**不在该PR原有合并内容中**。
- 三维固定源码：[迁移592bea7](https://github.com/TophBeifong1744/SoundSight/tree/592bea7abac5629af884e237bb8b679a4e7fe529/software/tetra3d)、[DAS基线3347989](https://github.com/TophBeifong1744/SoundSight/tree/3347989eb03488a33c88c241c75eed517d3a30f0/software/tetra3d/das)、[模块接合dfe9975](https://github.com/TophBeifong1744/SoundSight/tree/dfe9975168bae92af34b9c25891c3678bc5d1dc6/software/tetra3d)。不要用当前工作树内容冒充历史基准。
- 声纹原v3：[公开源码快照](https://github.com/TophBeifong1744/SoundSight/releases/tag/speaker-b-handoff-20261026-v3)。CP1/VF1属于后续候选，不倒写进原v3实验。
- 最新声纹私下交接：[CP1/VF1接合入口](../references/SoundSight-speaker-b/document/handoff-a-speaker-cp1-vf1-20261028/START-HERE.md)、已有交接包（历史外部引用，未随本资料包附带：`SoundSight-speaker-b/delivery/soundsight_A_speaker_cp1_vf1_private_20261028.zip`）。该包不是最终三维整机包，也不含原板真实P02模板。
- AF1：增量包（历史外部引用，未随本资料包附带：`SoundSight-speaker-b/delivery/soundsight_follow_sound_af1.zip`）；机械问题：B给A的交接包（历史外部引用，未随本资料包附带：`SoundSight-speaker-b/delivery/soundsight_B_to_A_vertical_no_motion_20261029.zip`）。已有包保留，本轮不重打包、不执行安装。

本轮只新增本资料稿，保留原证据、产品源码和他人进行中修改。核对的是文档引用、已有数值和实现边界，不产生新的板测结论；未发布、未向A发送消息。本交接副本已将可提供的引用转换为包内相对路径；未附的既有运行包明确标注。
