# 未附的历史外部引用

主稿直接引用的源码/报告/数据均已提供；三个既有ZIP未重复装入，相关说明已改写为普通文字。
下表包括嵌套历史文档中的进一步链接。这些不是当前主稿的新增实验依据，不代表要求A执行旧工作。

|引用文档|未附路径|
|---|---|
|`SoundSight-b-algorithm/software/common/s1/README.md`|`stm32/FROZEN_SSOT_ABI.md`|
|`SoundSight-b-algorithm/software/common/s1/README.md`|`stm32/fpga_stm32_abi_frozen.h`|
|`SoundSight-b-algorithm/software/common/s1/README.md`|`stm32/s1/build/compile-frozen.log`|
|`SoundSight-b-algorithm/software/common/s1/README.md`|`stm32/s1/build/run-frozen.log`|
|`SoundSight-b-algorithm/software/common/s1/README.md`|`stm32/s1/doa_solver.c`|
|`SoundSight-b-algorithm/software/common/s1/README.md`|`stm32/s1/doa_solver.h`|
|`SoundSight-b-algorithm/software/common/s1/README.md`|`stm32/s1/test_doa_solver.c`|
|`SoundSight-report-b/document/evidence/speaker-report-materials/07-b-contribution-and-gaps-20261029.md`|`SoundSight-speaker-b/delivery/soundsight_A_speaker_cp1_vf1_private_20261028.zip`|
|`SoundSight-report-b/document/evidence/speaker-report-materials/07-b-contribution-and-gaps-20261029.md`|`SoundSight-speaker-b/delivery/soundsight_B_to_A_vertical_no_motion_20261029.zip`|
|`SoundSight-report-b/document/evidence/speaker-report-materials/07-b-contribution-and-gaps-20261029.md`|`SoundSight-speaker-b/delivery/soundsight_follow_sound_af1.zip`|
|`SoundSight-stm32/document/evidence/stm32-p4-acquire-diag-20261019/G02-R01.md`|`SoundSight-stm32/document/evidence/stm32-p4-acquire-diag-20261019/G02-R01-uart.txt`|
|`SoundSight-stm32/software/common/s1/README.md`|`stm32/FROZEN_SSOT_ABI.md`|
|`SoundSight-stm32/software/common/s1/README.md`|`stm32/fpga_stm32_abi_frozen.h`|
|`SoundSight-stm32/software/common/s1/README.md`|`stm32/s1/build/compile-frozen.log`|
|`SoundSight-stm32/software/common/s1/README.md`|`stm32/s1/build/run-frozen.log`|
|`SoundSight-stm32/software/common/s1/README.md`|`stm32/s1/doa_solver.c`|
|`SoundSight-stm32/software/common/s1/README.md`|`stm32/s1/doa_solver.h`|
|`SoundSight-stm32/software/common/s1/README.md`|`stm32/s1/test_doa_solver.c`|
