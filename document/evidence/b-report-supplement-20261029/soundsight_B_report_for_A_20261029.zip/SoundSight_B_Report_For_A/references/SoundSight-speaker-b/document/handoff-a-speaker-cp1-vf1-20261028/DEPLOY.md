# 交付与复现步骤

本外层ZIP在电脑上解压，不是可执行SD安装包。先运行 `python3 verify_handoff.py`。不要把外层整包塞进空间有限的SD启动分区，按需要传单个内层更新包。

## A接入现有总工程

1. 保留自己的工程提交和板端P02配置，读根目录接入说明。
2. 直接取 `models/cp1/fixed98.onnx` 和 `models/vf1/vad16_fixed.onnx` 放到A的版本化模型目录，无须本机ONNX转换。保留原模型，合并显式选择和哈希校验。
3. 根据 `source/` 与自己的现有代码逐项合并，保持唯一采集者和结果时效。不要把整个source目录或原完整部署包覆盖到总工程。
4. 按 `ACCEPTANCE.md` 先离线再无动作实麦。完成后A回交源码提交、实际配置及日志。

本次直接模型文件与安装包生成的模型逐字节核对。源码中运行入口仍是基线版本，A必须实现路径选择；拷贝模型不会自动启用。

## 原用户板复现实验

该板已依次安装以下支持包，最近VF1 check/bench已成功，无须重装或重复测速。需要查当前目标可运行原 `sudo sh speaker-target.sh status`；应保持P02 score-only，不能重做登记覆盖。

## 新目录重建参考环境

仅在一个新的空目录中展开 `board-packages/soundsight_pynq_speaker_full_profile.zip`。不要覆盖现有总工程。原包包含旧bit/hwh，只作历史复现资产，不自动prepare、下载或切换PL。

在PYNQ上，用同一目标根目录按以下顺序运行每个ZIP的Python安装器：

1. `soundsight_p02_target_v1_private.zip`
2. `soundsight_capture_cpu_opt_rx4.zip`
3. `soundsight_runtime_memory_mp1.zip`
4. `soundsight_fixed_window_fs1.zip`
5. `soundsight_packed_cam_cp1.zip`
6. `soundsight_vad_frontend_vf1.zip`

每条形式是 `sudo python3 /path/to/package.zip --root /path/to/SoundSight_PYNQ_Speaker_Live`；实际路径由A确认。先检查前一条成功再继续。MP1/FS1是对照工具依赖，不激活其后端。CP1/FS1安装器复用原权重重建，不需板上安装ONNX库。

新目录不含原板真实P02 profile/选择文件。由A获得用户授权的真实配置并使用原工具校验；不要复制本地控制测试夹具充当本人模板，也不要用P01冒充P02。原板真实配置路径为 `speaker-profiles/P02-v1/` 与 `speaker-target.local.json`，需连同关联资产完整保存。

有有效P02环境后，独立复现入口为 `sudo sh speaker-vad-frontend.sh check` 和 `sudo sh speaker-vad-frontend.sh bench`。只做离线运算，无需prepare或讲话；bench自动编译状态探针，原生产二进制保留。实验原始门限未达时仍报告NO_ADOPTION，这是预期如实行为，不为本次用户授权改输出。
