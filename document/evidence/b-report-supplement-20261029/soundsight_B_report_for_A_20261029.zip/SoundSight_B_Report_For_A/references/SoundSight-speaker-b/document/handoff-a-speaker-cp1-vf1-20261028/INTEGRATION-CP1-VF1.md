# CP1与VF1如何接入

以下路径相对 `source/`；板上路径相对 `/home/xilinx/SoundSight_PYNQ_Speaker_Live`。本文描述A需要完成的适配，不声称这些在线修改已经实现。已有完整PCM、生命周期和结果字段见 `baseline-docs/INTEGRATION.md`。

## 模型与接口

| 对象 | 接入要求 |
|---|---|
| CP1 | `models/cp1/fixed98.onnx`，SHA256 `5012f8f3afd594943d37384524a8b596b1fc860c5f371058b783c396411396ac` |
| CP1输入 | 当前原生J协议的7840个float32，即[1,98,80]；一秒16kHz窗、400点帧长、160点hop，经原C处理后进入模型，不能直接喂PCM |
| CP1输出 | 原192维embedding；继续使用原unit归一化及与模板的余弦相似度，原权重值保留 |
| VF1 | `models/vf1/vad16_fixed.onnx`，SHA256 `2f9baaee7df0ff223225b6fcb176ad0ae33542c7ae83015d7f87351c5c32d84c` |
| VF1输入 | 原生前端固定16kHz，input[1,576]，state[2,1,128]，sr保持原ABI |
| VF1状态 | 连续传递全部循环状态，不能每块清零；会话重置沿用原Z命令；0.5/0.35迟滞和voice_epoch保持 |
| 原生执行器 | 原`software/ps/speaker_core/pipeline_backend`及ORT 1.17.3；原frontend.f32保持，不需要采用MP1新二进制 |

CP1只有98帧版本。1.5/2秒或其他帧数必须在启动前选择原动态模型，或明确拒绝该配置；不能裁剪/补零凑98帧后冒充同一算法。模板登记及历史全语音评估仍用原动态模型；本包没有改变登记算法，也没有要求重新登记P02。

VF1图中保留sr输入，但展开分支后不再检查其值；调用层必须检查16000、固定输入和状态形状。ONNX形状检查不能替代sr检查。原生实现的硬编码和源码哈希已在独立板测确认；A若改采样率或前端，必须停止使用本候选并重新验证。

## A需要修改的具体位置

1. `software/ps/speaker_core/pipeline_bench.py` 的 `Backend.__init__`：目前支持 `model_filename`，但VAD参数仍固定为 `root/models/silero_vad.onnx`。保留原默认参数，新增显式VAD路径选项。绝对CP1模型路径已经可通过现有 `model_filename` 传入；测试参考 `tools/packed_cam_opt.py:embedding_backend`。VF1参数构造参考 `tools/vad_frontend_opt.py:FrontendBackend`，仅参考模型路径选择，不把实验状态探针作为生产依赖。
2. `software/ps/speaker_process.py` 的 `ProcessSpeaker` 配置和 `worker()` 内 `backend(path, role)`：当前不会传候选路径。增加版本化模型选择配置，将CP1只路由至embed，VF1只路由至front，父/子进程一致记录配置。保留现有profile分支的参数兼容；其 `ProfileBackend` 继承路径也需一起检查。
3. `software/ps/live_speaker.py`：已有 `backend_factory` 注入点。在线启动核对window=1.0；推理前确认frames=98、features长度7840且数值有限。更改窗口应结束旧会话并重建模型/缓存，不能跨模型继续旧身份。
4. `software/ps/speaker_settings.py`、`speaker_targets.py`及各资产清单：保留原模型/前端/模板的校验，另给A发布版本登记CP1/VF1哈希和所用源码。不要直接覆盖原文件名后删除哈希检查，也不要把P02登记时绑定的原资产全部替换为候选哈希。版本兼容关系应显式声明，原实验清单仅用于复现。
5. 输出附加实际模型版本/哈希及目标模板标识，使A能确定一次评分使用哪套模型。当前只有诊断stdout逐次结果和结束汇总；A仍需补有界、非阻塞实时结果通道。

原生进程实际参数关系如下，保留原二进制协议和调度前缀；这是调用说明，不是让用户直接在终端运行二进制：

```text
embed: pipeline_backend <CP1绝对路径> <原VAD路径> <原frontend.f32> 2 embed
front: pipeline_backend <原embedding路径> <VF1绝对路径> <原frontend.f32> 1 front
```

front角色不会加载embedding，embed角色不会加载VAD。原C内部VAD session原本就是1线程。保持原embedding双线程CPU0/1、nice+10及前端CPU1，采集CPU0；不要把参数变化误称为新的线程优化。VF1实验构建只新增H读状态命令；原生产二进制没有H，不要向它发送H。

## 总工程合并时保持的行为

沿用RX4的48kHz四通道S24扩展S32小端包（8224字节），每3包形成1536帧原生前端输入；当前取mic0。现有四麦定位与声纹共享同一采集所有者，不能新启独占run_pcm抢DMA。当前算法不包含多说话人分离，也没有接DAS；改通道或接增强音频需要另做声纹分布验证。

保持1秒窗、0.5秒hop、0.25秒最大启动年龄、2秒最大结果年龄、0.5秒前端积压、32包信用和最新待处理窗口策略。不要延长TTL、提高nice优先级或自动清错来掩盖延迟。nice0此前出现fault8/drop1，不能沿用作捷径。

P02是score-only，score不是概率。目标判断、定位角度必须关联同一epoch与实际采样区间；输出迟到时不能附上当前角度。会话结束、语音状态变化、故障、丢包和过期必须撤销旧身份。接入阶段不驱动舵机。

## 回退

A应保留显式原版选项（原动态embedding+原VAD）。切换前停止旧会话、关闭两个后端并撤销身份，再加载原版；不要在处理中的会话悄悄切换。P02配置与原资产保留。实验工具的安装回退只删除对应新增工具/模型，不能代替A总工程源码的回退；A需单独保存自己的接入提交和配置。
