"""VF1 isolated ARM frontend replay. No capture, activation or live command."""
import argparse
import array
from contextlib import contextmanager, ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tempfile

import runtime_memory_opt as mp1
import packed_cam_opt as cp1
from fixed_window_opt import compare_embeddings, TOLERANCES as EMBEDDING_TOLERANCES

ROOT = Path(__file__).resolve().parents[1]
CORE_REL = mp1.CORE_REL
MODEL_REL = 'speaker-compute-candidates/vf1/vad16_fixed.onnx'
INFO_REL = 'speaker-compute-candidates/vf1/candidate-info.json'
JOBS = ('window-16320.f32', 'window-80320.f32', 'window-144320.f32')
TOLERANCES = dict(probability_abs=1e-5, state_relative_l2=1e-5, state_max_abs=1e-5)
PERFORMANCE_GATES = dict(rounds=4, min_frontend_wall_reduction=.20,
    min_frontend_cpu_reduction=.20, min_combined_wall_reduction=.20,
    min_incremental_wall_reduction=.05, max_embedding_cpu_regression=.05,
    min_positive_paced_rounds=3, max_frontend_lag_seconds=.5)
ANCHOR = '        uint32_t n; rd(&n,4);'
PROBE = '''#ifdef SS_STREAMING
        if(cmd=='H') {
            if(!front_only)die("VF1_STATE_FRONT_ONLY");
            uint32_t count=256;wr(&count,4);
            wr(stream_state.state,sizeof(stream_state.state));fflush(stdout);continue;
        }
#endif
'''


def verify(root=ROOT):
    root = Path(root)
    manifest = json.loads((root/'vad-frontend-assets.json').read_text())
    if manifest.get('revision') != 'VF1':
        raise ValueError('VF1_MANIFEST')
    hashes = manifest.get('sha256', {})
    if MODEL_REL not in hashes or INFO_REL not in hashes:
        raise ValueError('VF1_CANDIDATE_NOT_BOUND')
    for name, digest in hashes.items():
        path = (root/name).resolve()
        if root.resolve() not in path.parents or mp1.sha(path) != digest:
            raise ValueError('VF1_ASSET_MISMATCH: '+name)
    cfg = cp1.verify(root)
    info = json.loads((root/INFO_REL).read_text())
    expected = dict(revision='VF1', fixed_sr=16000, input_shape=[1, 576],
        state_shape=[2, 1, 128], guard_required=True, tolerances=TOLERANCES,
        performance_gates=PERFORMANCE_GATES)
    if any(info.get(k) != v for k, v in expected.items()):
        raise ValueError('VF1_POLICY_CHANGED')
    if info.get('candidate_sha256') != hashes[MODEL_REL]:
        raise ValueError('VF1_CANDIDATE_INFO_HASH')
    return cfg


def require_idle():
    cp1.require_idle()
    for path in Path('/proc').glob('[0-9]*/cmdline'):
        if path.parent.name == str(os.getpid()):
            continue
        try:
            names = {Path(os.fsdecode(x)).name for x in path.read_bytes().split(b'\0') if x}
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
        if names & {'vad_frontend_opt.py', 'vf1_probe'}:
            raise RuntimeError('STOP_ACTIVE_VF1_FIRST: '+path.parent.name)


def probe_source(source):
    """One additive command, with exact anchors for the fixed native VAD ABI."""
    checks = (ANCHOR, 'int64_t sr=16000; const int64_t id[]={1,576},sd[]={2,1,128};',
              'OrtSession *vad=embed_only?NULL:make_session(argv[2],1,"vad");')
    if any(source.count(s) != 1 for s in checks) or "cmd=='H'" in source or 'VF1_STATE_FRONT_ONLY' in source:
        raise ValueError('VF1_UNEXPECTED_NATIVE_SOURCE')
    return source.replace(ANCHOR, PROBE+ANCHOR)


def build_probe(root, folder):
    core = root/CORE_REL
    build = folder/'native-build'; build.mkdir()
    cc = shutil.which('gcc')
    if not cc:
        raise RuntimeError('GCC_MISSING')
    originals = {name: (core/'source'/name).read_bytes() for name in mp1.SOURCES}
    for name, data in originals.items():
        (build/name).write_bytes(data)
    # Preserve original bytes and line endings in the copied source.
    source = originals['pipeline_backend.c'].decode('ascii')
    patched = probe_source(source)
    (build/'vf1_probe.c').write_bytes(patched.encode('ascii'))
    binary = build/'vf1_probe'
    command = mp1.compile_command(cc, build/'vf1_probe.c', binary, core, root/'tools/ort-1.17.3')
    compiler_version = subprocess.check_output([cc, '--version'], timeout=15, text=True).splitlines()[0]
    meta = dict(revision='VF1', hardware_access=False, command=command, compiler=compiler_version,
        source_sha256={n: hashlib.sha256(b).hexdigest() for n, b in originals.items()},
        probe_source_sha256=mp1.sha(build/'vf1_probe.c'),
        runtime_sha256=mp1.sha(core/'lib/libonnxruntime.so.1.17.3'),
        header_sha256=mp1.sha(root/'tools/ort-1.17.3/onnxruntime_c_api.h'),
        binary=str(binary.resolve()), state_opcode='H', status='BUILDING')
    mp1.write_json(build/'build.json', meta)
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
        (build/'stdout.log').write_bytes(result.stdout)
        (build/'stderr.log').write_bytes(result.stderr)
        if result.returncode:
            raise RuntimeError('VF1_BUILD_FAILED: '+str(build/'stderr.log'))
        header = binary.read_bytes()[:20]
        if len(header) < 20 or header[:6] != b'\x7fELF\x01\x01' or header[18:20] != b'\x28\x00':
            raise RuntimeError('NOT_ARM32_LITTLE_ENDIAN_ELF')
        if any((core/'source'/n).read_bytes() != b for n, b in originals.items()):
            raise RuntimeError('ORIGINAL_NATIVE_SOURCE_CHANGED')
        meta.update(status='PASS', binary_sha256=mp1.sha(binary))
    except subprocess.TimeoutExpired as error:
        (build/'stdout.log').write_bytes(error.stdout or b'')
        (build/'stderr.log').write_bytes((error.stderr or b'')+b'\nBUILD_TIMEOUT\n')
        meta.update(status='FAIL', error='BUILD_TIMEOUT')
        raise RuntimeError('VF1_BUILD_TIMEOUT') from error
    except BaseException as error:
        meta.update(status='FAIL', error=type(error).__name__+': '+str(error))
        raise
    finally:
        mp1.write_json(build/'build.json', meta)
    return meta


class FrontendBackend:
    """Use original Backend methods/protocol with an explicit VAD model path."""
    def __init__(self, core, executable, vad_model, prefix):
        from pipeline_bench import Backend
        inner = Backend.__new__(Backend)
        inner.root = Path(core)
        self._inner = inner
        command = list(prefix)+[str(executable), str(core/'models/int8-head.onnx'),
            str(vad_model), str(core/'frontend.f32'), '1', 'front']
        inner.p = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        try:
            inner.loads = json.loads(inner.p.stdout.readline())
        except BaseException:
            try:
                inner.close(force=True)
            except BaseException:
                pass
            raise

    def __getattr__(self, name):
        return getattr(self._inner, name)

    def read_state(self):
        self.p.stdin.write(b'H'); self.p.stdin.flush()
        values = self._inner._reply()
        if len(values) != 256 or not all(math.isfinite(v) for v in values):
            raise ValueError('VF1_STATE_SHAPE_OR_VALUES')
        return values


@contextmanager
def frontend_backend(root, binary, variant, stderr_path):
    if variant not in ('original', 'vf1'):
        raise ValueError('VF1_FRONT_VARIANT')
    taskset, limiter = (shutil.which(n) for n in ('taskset', 'prlimit'))
    if not taskset or not limiter:
        raise RuntimeError('TASKSET_PRLIMIT_REQUIRED')
    prefix = [sys.executable, '-B', str(root/'tools/runtime_memory_opt.py'), '_native_exec',
        str(stderr_path), limiter, '--as=805306368', '--', taskset, '-c', '1']
    core = root/CORE_REL
    model = root/MODEL_REL if variant == 'vf1' else core/'models/silero_vad.onnx'
    with mp1.deadline():
        b = FrontendBackend(core, binary, model, prefix)
    try:
        if b.loads.get('ort') != '1.17.3':
            raise ValueError('BOARD_ORT_VERSION_CHANGED')
        yield b
    finally:
        primary = sys.exc_info()[1]
        try:
            b.close(force=primary is not None)
        except BaseException:
            if primary is None:
                raise


def compare_state(reference, actual):
    if len(reference) != 256 or len(actual) != 256:
        raise ValueError('VF1_STATE_SHAPE')
    match = mp1.compare_vectors(reference, actual)
    norm = math.sqrt(sum(x*x for x in reference))
    error = math.sqrt(sum((x-y)**2 for x, y in zip(reference, actual)))
    relative = error/max(norm, 1e-8)
    if not math.isfinite(relative):
        raise ValueError('VF1_STATE_NORM')
    return dict(state_relative_l2=relative, state_max_abs=match['max_abs_diff'],
        bit_exact=match['exact'], passed=relative <= TOLERANCES['state_relative_l2']
        and match['max_abs_diff'] <= TOLERANCES['state_max_abs'])


def compare_packet(reference, actual, require_exact_features):
    for packet in (reference, actual):
        if (len(packet) < 515 or packet[0] != 512 or packet[1] not in (1, 2, 3, 4)
                or len(packet) != 515+int(packet[1])*80
                or not all(math.isfinite(v) for v in packet) or not 0 <= packet[2] <= 1):
            raise ValueError('VF1_FRONTEND_PACKET_SHAPE_OR_VALUES')
    # The FIR/audio and mel outputs must not change when only VAD is specialized.
    match = mp1.compare_vectors(list(reference[:2])+list(reference[3:]),
                                list(actual[:2])+list(actual[3:]))
    probability = abs(reference[2]-actual[2])
    return dict(probability_abs=probability, features_bit_exact=match['exact'],
        features_max_abs=match['max_abs_diff'], bit_exact=match['exact'] and
        array.array('f', [reference[2]]).tobytes() == array.array('f', [actual[2]]).tobytes(),
        passed=probability <= TOLERANCES['probability_abs'] and
        (match['exact'] if require_exact_features else match['max_abs_diff'] <= 1e-5))


def numerical_replay(fronts, raw, cases):
    from stream_bench import Cache, reset
    if len(raw) != 312*mp1.CHUNK:
        raise ValueError('VF1_EXPECTED_312_PCM_BLOCKS')
    # Each process retains its own recurrent state throughout each sequence.
    streams = [('recording_then_silence', raw+bytes(mp1.CHUNK*32)),
               ('reset_boundary', raw[:mp1.CHUNK*8]+bytes(mp1.CHUNK*8))]
    first = None
    for sequence, data in streams:
        caches = {n: Cache() for n in fronts}
        for n, front in fronts.items():
            reset(front)
            if n != 'shipped' and any(front.read_state()):
                raise ValueError('VF1_STATE_RESET_FAILED')
        for pos in range(0, len(data), mp1.CHUNK):
            outputs = {n: b.run_pcm32(data[pos:pos+mp1.CHUNK]) for n, b in fronts.items()}
            for n, output in outputs.items():
                caches[n].push(output)
            baseline = compare_packet(outputs['shipped'], outputs['rebuild'], False)
            candidate = compare_packet(outputs['rebuild'], outputs['vf1'], True)
            states = {n: fronts[n].read_state() for n in ('rebuild', 'vf1')}
            recurrent = compare_state(states['rebuild'], states['vf1'])
            decisions = len({(c.active, c.voice_epoch) for c in caches.values()}) == 1
            row = dict(sequence=sequence, block=pos//mp1.CHUNK, baseline=baseline,
                candidate=candidate, recurrent=recurrent, vad_decisions_equal=decisions,
                active=caches['rebuild'].active, voice_epoch=caches['rebuild'].voice_epoch)
            cases.append(row)
            if not all((baseline['passed'], candidate['passed'], recurrent['passed'], decisions)):
                raise ValueError('VF1_NATIVE_NUMERIC_GATE: '+sequence+':'+str(pos//mp1.CHUNK))
            if pos == 0:
                if first is None:
                    first = {n: array.array('f', a).tobytes() for n, a in outputs.items()}
                elif any(first[n] != array.array('f', a).tobytes() for n, a in outputs.items()):
                    raise ValueError('VF1_RESET_BOUNDARY_MISMATCH')
                if fronts['rebuild'].read_state() != states['rebuild'] or fronts['vf1'].read_state() != states['vf1']:
                    raise ValueError('VF1_STATE_READ_MUTATED_STATE')
            if sequence == 'recording_then_silence' and pos == 311*mp1.CHUNK:
                if not any(states['rebuild']):
                    raise ValueError('VF1_NONZERO_CARRY_NOT_EXERCISED')
    return dict(blocks=len(cases), reset_sequences=len(streams),
        nonzero_state_into_silence=True, exact_vad_decisions=True,
        all_candidate_bit_exact=all(r['candidate']['bit_exact'] and r['recurrent']['bit_exact'] for r in cases),
        all_rebuilt_baseline_bit_exact=all(r['baseline']['bit_exact'] for r in cases),
        worst_probability_abs=max(r['candidate']['probability_abs'] for r in cases),
        worst_state_relative_l2=max(r['recurrent']['state_relative_l2'] for r in cases),
        worst_state_max_abs=max(r['recurrent']['state_max_abs'] for r in cases))


def performance_summary(rows):
    specs = {'frontend': (('original', 'vf1'), ('epoch26',)),
             'paced_frontend': (('shipped', 'cp1', 'vf1'), JOBS)}
    expected = {(mode, v, rnd, case, rep) for mode, (variants, cases) in specs.items()
                for v in variants for rnd in range(1, 5) for case in cases for rep in (0, 1)}
    table = {}
    for row in rows:
        key = tuple(row.get(k) for k in ('mode', 'variant', 'round', 'case', 'pass'))
        if (key not in expected or type(row.get('round')) is not int or
                type(row.get('pass')) is not int or key in table):
            raise ValueError('VF1_TIMING_ROW_ID_OR_DUPLICATE')
        for field in ('wall_seconds', 'cpu_seconds'):
            value = row.get(field)
            if type(value) not in (float, int) or not math.isfinite(value) or value <= 0:
                raise ValueError('VF1_TIMING_UNRESOLVED_OR_NONFINITE: '+field)
        table[key] = row
    if set(table) != expected:
        raise ValueError('VF1_INCOMPLETE_PAIRED_TIMING_MATRIX')
    out = {}
    for mode, (variants, _) in specs.items():
        warm = [r for r in table.values() if r['mode'] == mode and r['pass'] == 1]
        stats = {}
        for variant in variants:
            group = [r for r in warm if r['variant'] == variant]
            stats[variant] = dict(samples=len(group),
                median_wall_seconds=statistics.median(r['wall_seconds'] for r in group),
                median_cpu_seconds=statistics.median(r['cpu_seconds'] for r in group),
                max_wall_seconds=max(r['wall_seconds'] for r in group),
                peak_rss_mib=max(r.get('peak_rss_mib', 0.) for r in group))
        rounds = [{v: statistics.median(r['wall_seconds'] for r in warm
                   if r['round'] == rnd and r['variant'] == v) for v in variants}
                  for rnd in range(1, 5)]
        out[mode] = dict(variants=stats, per_round=[dict(round=i+1, **r) for i, r in enumerate(rounds)])
    return out


def performance_decision(performance, numeric_pass, producer_runs):
    if type(numeric_pass) is not bool:
        raise ValueError('VF1_NUMERIC_PASS_BOOLEAN_REQUIRED')
    expected = {(rnd, variant) for rnd in range(1, 5) for variant in ('shipped', 'cp1', 'vf1')}
    if (len(producer_runs) != len(expected) or
            {(r.get('round'), r.get('variant')) for r in producer_runs} != expected):
        raise ValueError('VF1_PRODUCER_MATRIX_INCOMPLETE')
    frontend_ok = all(r.get('error') is None and type(r.get('blocks')) is int and r['blocks'] >= 3
        and type(r.get('max_lag_seconds')) in (int, float) and math.isfinite(r['max_lag_seconds'])
        and 0 <= r['max_lag_seconds'] <= PERFORMANCE_GATES['max_frontend_lag_seconds'] for r in producer_runs)
    a, b = (performance['frontend']['variants'][v] for v in ('original', 'vf1'))
    s, c, v = (performance['paced_frontend']['variants'][n] for n in ('shipped', 'cp1', 'vf1'))
    rounds = performance['paced_frontend']['per_round']
    if len(rounds) != 4 or {r['round'] for r in rounds} != set(range(1, 5)):
        raise ValueError('VF1_PER_ROUND_COVERAGE')
    positive = sum(r['vf1'] < r['cp1'] for r in rounds)
    checks = dict(numeric_pass=numeric_pass, frontend_no_errors_or_excess_lag=frontend_ok,
        frontend_wall_reduction_at_least_20_percent=b['median_wall_seconds'] <= a['median_wall_seconds']*
            (1-PERFORMANCE_GATES['min_frontend_wall_reduction']),
        frontend_cpu_reduction_at_least_20_percent=b['median_cpu_seconds'] <= a['median_cpu_seconds']*
            (1-PERFORMANCE_GATES['min_frontend_cpu_reduction']),
        combined_wall_reduction_at_least_20_percent=v['median_wall_seconds'] <= s['median_wall_seconds']*
            (1-PERFORMANCE_GATES['min_combined_wall_reduction']),
        incremental_wall_reduction_at_least_5_percent=v['median_wall_seconds'] <= c['median_wall_seconds']*
            (1-PERFORMANCE_GATES['min_incremental_wall_reduction']),
        embedding_cpu_within_5_percent=v['median_cpu_seconds'] <= c['median_cpu_seconds']*
            (1+PERFORMANCE_GATES['max_embedding_cpu_regression']),
        positive_paced_rounds_at_least_3=positive >= PERFORMANCE_GATES['min_positive_paced_rounds'])
    return dict(eligible_for_future_live_trial=all(checks.values()), checks=checks,
        positive_paced_rounds=positive, required_gates=PERFORMANCE_GATES,
        realtime_qualified=False, recognition_qualified=False, active_backend_changed=False,
        frontend_wall_reduction=1-b['median_wall_seconds']/a['median_wall_seconds'],
        frontend_cpu_reduction=1-b['median_cpu_seconds']/a['median_cpu_seconds'],
        combined_wall_reduction=1-v['median_wall_seconds']/s['median_wall_seconds'],
        incremental_wall_reduction=1-v['median_wall_seconds']/c['median_wall_seconds'])


def close_producer(producer, report, rnd, variant):
    primary = sys.exc_info()[1]
    try:
        producer.close()
    except BaseException as error:
        report.setdefault('cleanup_errors', []).append(type(error).__name__+': '+str(error))
        if primary is None:
            raise
    finally:
        report['producer_runs'].append(dict(round=rnd, variant=variant,
            blocks=producer.blocks, cycles=producer.cycles,
            max_lag_seconds=producer.max_lag_seconds, error=producer.error))


def bench(root=ROOT):
    root = Path(root)
    cfg = verify(root)
    mp1.require_arm(); require_idle()
    from cpu_profile_bench import PacedFront
    affinity = set(os.sched_getaffinity(0))
    env = {key: os.environ.pop(key, None) for key in
           ('SS_ORT_PROFILE_DIR', 'SS_SPEAKER_DETAIL_PROFILE', 'SS_SPEAKER_CPU_PROFILE')}
    (root/'logs').mkdir(exist_ok=True)
    folder = Path(tempfile.mkdtemp(prefix='vad-frontend-', dir=str(root/'logs')))
    os.chmod(folder, 0o700)
    report = dict(revision='VF1', status='RUNNING', scope='OFFLINE_NATIVE_REPLAY_NO_DMA',
        hardware_access=False, active_backend_changed=False, template_changed=False,
        recognition_qualified=False, realtime_qualified=False, eligible_for_future_live_trial=False,
        tolerances=TOLERANCES, embedding_tolerances=EMBEDDING_TOLERANCES,
        performance_gates=PERFORMANCE_GATES, rows=[], cases=[], producer_runs=[],
        policy=dict(driver_cpu=1, frontend_cpu=1, vad_threads=1, embedding_cpus=[0, 1],
            embedding_threads=2, embedding_nice_increment=10, memory_pattern=False,
            paced_frontend_binary='same_rebuilt_probe_for_all_three_variants',
            shipped_frontend_comparison='separate_numerical_stage'),
        candidate_sha256=mp1.sha(root/MODEL_REL))
    mp1.write_json(folder/'result.json', report)
    print('VF1_BENCH_BEGIN NO_CAPTURE=1 NO_SPEECH_NEEDED=1', flush=True)
    print('OUTPUT='+str(folder.resolve()), flush=True)
    try:
        os.sched_setaffinity(0, {1})
        core = root/CORE_REL
        raw = (core/'profile/epoch26.pcm32').read_bytes()
        if len(raw) != 312*mp1.CHUNK:
            raise ValueError('VF1_EXPECTED_312_PCM_BLOCKS')
        jobs = {}
        for name in JOBS:
            values = array.array('f'); values.frombytes((core/'profile'/name).read_bytes())
            if len(values) != 98*80 or not all(math.isfinite(x) for x in values):
                raise ValueError('VF1_FEATURE_SHAPE_OR_VALUES')
            jobs[name] = values
        report['build'] = build_probe(root, folder)
        probe = Path(report['build']['binary'])
        with ExitStack() as stack:
            fronts = {name: stack.enter_context(frontend_backend(root, binary, variant,
                      folder/('numeric-'+name+'.stderr.log')))
                for name, binary, variant in (('shipped', core/'pipeline_backend', 'original'),
                    ('rebuild', probe, 'original'), ('vf1', probe, 'vf1'))}
            with mp1.deadline(180):
                report['native_numeric'] = numerical_replay(fronts, raw, report['cases'])
        mp1.write_json(folder/'result.json', report)
        for rnd in range(1, 5):
            for variant in (('original', 'vf1') if rnd % 2 else ('vf1', 'original')):
                print('ROUND=%d MODE=frontend VARIANT=%s' % (rnd, variant), flush=True)
                with frontend_backend(root, probe, variant, folder/('throughput-%d-%s.stderr.log' % (rnd, variant))) as front:
                    for rep in (0, 1):
                        _, timing = mp1.measured(front, lambda: mp1.replay(front, raw, collect=False))
                        report['rows'].append(dict(round=rnd, mode='frontend', variant=variant,
                            case='epoch26', **{'pass': rep}, **timing))
                mp1.write_json(folder/'result.json', report)
        references = {}
        with cp1.embedding_backend(root, 'shipped', folder/'embedding-reference.stderr.log') as embed:
            for name, features in jobs.items():
                with mp1.deadline():
                    references[name] = embed.run('J', features)
        orders = (('shipped', 'cp1', 'vf1'), ('vf1', 'cp1', 'shipped'),
                  ('cp1', 'vf1', 'shipped'), ('shipped', 'vf1', 'cp1'))
        for rnd, order in enumerate(orders, 1):
            for variant in order:
                print('ROUND=%d MODE=paced_frontend VARIANT=%s' % (rnd, variant), flush=True)
                with cp1.embedding_backend(root, 'shipped' if variant == 'shipped' else 'cp1',
                        folder/('embed-%d-%s.stderr.log' % (rnd, variant))) as embed:
                    with frontend_backend(root, probe, 'vf1' if variant == 'vf1' else 'original',
                            folder/('front-%d-%s.stderr.log' % (rnd, variant))) as front:
                        producer = PacedFront(front, raw)
                        try:
                            producer.start()
                            for rep in (0, 1):
                                for name, features in jobs.items():
                                    producer.check()
                                    output, timing = mp1.measured(embed, lambda: embed.run('J', features))
                                    match = compare_embeddings(references[name], output, cfg['template'])
                                    report['rows'].append(dict(round=rnd, mode='paced_frontend',
                                        variant=variant, case=name, **{'pass': rep}, **timing, numeric=match))
                                    if not match['passed']:
                                        raise ValueError('VF1_EMBEDDING_NUMERIC_GATE: '+name)
                                    producer.check()
                        finally:
                            close_producer(producer, report, rnd, variant)
                mp1.write_json(folder/'result.json', report)
        report['performance'] = performance_summary(report['rows'])
        embeddings = [r['numeric'] for r in report['rows'] if 'numeric' in r]
        report['worst_embedding_numeric'] = {key: max(r[key] for r in embeddings)
                                             for key in EMBEDDING_TOLERANCES}
        report['all_embedding_bit_exact'] = all(r['bit_exact'] for r in embeddings)
        report['performance_decision'] = performance_decision(report['performance'], True, report['producer_runs'])
        report['eligible_for_future_live_trial'] = report['performance_decision']['eligible_for_future_live_trial']
        report['status'] = ('NUMERIC_PASS_SIGNIFICANT_OFFLINE_BENEFIT_LIVE_NOT_TESTED'
            if report['eligible_for_future_live_trial'] else 'NUMERIC_PASS_NO_ADOPTION')
    except BaseException as error:
        report.update(status='FAIL', error=type(error).__name__+': '+str(error))
        raise
    finally:
        primary = sys.exc_info()[1]
        try:
            os.sched_setaffinity(0, affinity)
        except BaseException as error:
            report.setdefault('cleanup_errors', []).append(type(error).__name__+': '+str(error))
            report.update(status='FAIL', eligible_for_future_live_trial=False)
            if primary is None:
                report['error'] = 'AFFINITY_RESTORE_FAILED: '+str(error)
        for key, value in env.items():
            if value is not None:
                os.environ[key] = value
        mp1.write_json(folder/'result.json', report)
        summary = {k: v for k, v in report.items() if k not in ('rows', 'cases')}
        mp1.write_json(folder/'summary.json', summary)
        print(json.dumps(summary, indent=2), flush=True)
        print('OUTPUT='+str(folder.resolve()), flush=True)
        print('VF1_ACTIVE_BACKEND_UNCHANGED=1 NO_LIVE_ACCEPTANCE=1', flush=True)
    if report['status'] == 'FAIL':
        raise RuntimeError(report.get('error', 'VF1_CLEANUP_FAILED'))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('check', 'bench'))
    args = parser.parse_args()
    if args.command == 'check':
        verify()
        print('VF1_PACKAGE_OK=1 TARGET=P02 SCORE_ONLY=1 HARDWARE_ACCESS=0')
        return 0
    return bench()


if __name__ == '__main__':
    raise SystemExit(main())
