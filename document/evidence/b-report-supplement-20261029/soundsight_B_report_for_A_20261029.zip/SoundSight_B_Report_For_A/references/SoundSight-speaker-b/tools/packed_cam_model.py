"""CP1: checked fixed-98 CAM graph layout and eight-position context gates.

PC-only conversion of the pinned original. No online selection, model loading on
the board, template changes or numerical/performance acceptance is implied.
"""
import argparse
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path

import numpy as np
import onnx
from onnx import helper, numpy_helper

from cam_context_transform import transform_model as context_transform, stable_topological_sort

SOURCE_SHA256 = 'e14405d2580db61c1359808102c7f7f8ac73623303c2076087d2a9efd7ebc4f4'
GATE_WIDTH = 8
FEATURE_FRAMES = 98
BLOCK_LAYERS = (12, 24, 16)
PROJECTIONS = tuple('/model/xvector/block%d/tdnnd%d/linear1/Conv' % (block, layer)
                    for block, count in enumerate(BLOCK_LAYERS, 1) for layer in range(1, count+1))
PROJECTIONS += tuple('/model/xvector/transit%d/linear/Conv' % block for block in (1, 2, 3))
POINT_ATTRIBUTES = dict(auto_pad=b'NOTSET', dilations=[1], group=1,
                        kernel_shape=[1], pads=[0, 0], strides=[1])


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _require(condition, reason):
    if not condition:
        raise ValueError('CP1_STRUCTURE: '+reason)


def _tile_gates(model):
    """Context transformer already proved 52 single-segment [1,128,49] pools."""
    graph = model.graph
    extra = []
    tiled = []
    sliced = []
    names = {n.name for n in graph.node}
    tensor_names = {t.name for t in graph.initializer} | {v for n in graph.node for v in n.output}

    def add_constant(name, values):
        _require(name not in tensor_names, 'new constant collision: '+name)
        graph.initializer.append(numpy_helper.from_array(np.array(values, dtype=np.int64), name))
        tensor_names.add(name)
        return name

    def rewire(old, new):
        _require(new not in tensor_names, 'new tensor collision: '+new)
        tensor_names.add(new)
        users = []
        for consumer in graph.node:
            for i, value in enumerate(consumer.input):
                if value == old:
                    consumer.input[i] = new
                    users.append(consumer.name)
        return users

    for node in list(graph.node):
        if '/cam_layer/' not in node.name:
            continue
        if node.name.endswith('/Add'):
            output = node.output[0]+'_tile'
            repeats = add_constant(node.name+'_tile_repeats', [1, 1, GATE_WIDTH])
            users = rewire(node.output[0], output)
            prefix = node.name[:-len('Add')]
            _require(users == [prefix+'linear1/Conv'], 'unexpected pooled context consumer')
            _require(node.name+'_tile' not in names, 'Tile node collision')
            extra.append(helper.make_node('Tile', [node.output[0], repeats], [output], name=node.name+'_tile'))
            tiled.append(node.name)
        elif node.name.endswith('/sigmoid/Sigmoid'):
            output = node.output[0]+'_one'
            constants = [add_constant(node.name+'_'+tag, values)
                         for tag, values in (('starts', [0]), ('ends', [1]), ('axes', [2]))]
            users = rewire(node.output[0], output)
            prefix = node.name[:-len('sigmoid/Sigmoid')]
            _require(users == [prefix+'Mul_1'], 'unexpected singleton gate consumer')
            _require(node.name+'_one' not in names, 'Slice node collision')
            extra.append(helper.make_node('Slice', [node.output[0]]+constants, [output], name=node.name+'_one'))
            sliced.append(node.name)
    _require(len(tiled) == len(sliced) == 52, 'exactly 52 tiled and sliced gates required')
    ordered = stable_topological_sort(list(graph.node)+extra,
        {t.name for t in graph.initializer}, {i.name for i in graph.input})
    del graph.node[:]
    graph.node.extend(ordered)
    # All interfaces retain exact shapes; internal context shapes changed.
    del graph.value_info[:]
    return dict(tiled_gates=len(tiled), singleton_gate_slices=len(sliced))


def _pack_projections(model):
    graph = model.graph
    tensors = {t.name: t for t in graph.initializer}
    all_tensor_names = set(tensors) | {v for n in graph.node for v in n.output}
    wanted = set(PROJECTIONS)
    found = set()
    output_nodes = []
    changed = []
    replaced_weights = set()
    for node in graph.node:
        if node.name not in wanted:
            output_nodes.append(copy.deepcopy(node))
            continue
        _require(node.name not in found, 'duplicate projection node')
        found.add(node.name)
        _require(node.op_type == 'Conv' and node.domain in ('', 'ai.onnx'), 'projection op')
        _require(len(node.output) == 1 and len(node.input) in (2, 3), 'projection arity')
        _require({a.name: helper.get_attribute_value(a) for a in node.attribute} == POINT_ATTRIBUTES,
                 'projection convolution attributes')
        _require(node.input[1] in tensors, 'projection weight initializer missing')
        weight = numpy_helper.to_array(tensors[node.input[1]])
        _require(weight.dtype == np.float32 and weight.ndim == 3 and weight.shape[2] == 1,
                 'projection weight type/shape')
        _require(np.isfinite(weight).all(), 'projection nonfinite weight')
        transpose_name = node.name+'/PG1_WT'
        ntc, mm, added = [node.name+'/PG1_'+s for s in ('input_NTC', 'mm', 'bias')]
        for name in (transpose_name, ntc, mm, added):
            _require(name not in all_tensor_names, 'new tensor collision: '+name)
            all_tensor_names.add(name)
        transpose = np.ascontiguousarray(weight[:, :, 0].T)
        _require(np.array_equal(transpose.T.view(np.uint32), weight[:, :, 0].view(np.uint32)),
                 'transposed weight bits changed')
        graph.initializer.append(numpy_helper.from_array(transpose, transpose_name))
        output_nodes.extend([
            helper.make_node('Transpose', [node.input[0]], [ntc], name=node.name+'/PG1_transpose_in', perm=[0, 2, 1]),
            helper.make_node('MatMul', [ntc, transpose_name], [mm], name=node.name+'/PG1_matmul'),
        ])
        last = mm
        if len(node.input) == 3:
            _require(node.input[2] in tensors, 'projection bias initializer missing')
            bias = numpy_helper.to_array(tensors[node.input[2]])
            _require(bias.dtype == np.float32 and bias.shape == (weight.shape[0],)
                     and np.isfinite(bias).all(), 'projection bias type/shape/values')
            output_nodes.append(helper.make_node('Add', [mm, node.input[2]], [added], name=node.name+'/PG1_add'))
            last = added
        output_nodes.append(helper.make_node('Transpose', [last], list(node.output),
                                            name=node.name+'/PG1_transpose_out', perm=[0, 2, 1]))
        replaced_weights.add(node.input[1])
        changed.append(dict(node=node.name, original_weight=node.input[1],
                            transposed_weight=transpose_name, weight_shape=list(weight.shape)))
    _require(found == wanted and len(replaced_weights) == 55, 'exactly 55 distinct projection weights required')
    del graph.node[:]
    graph.node.extend(output_nodes)
    # The old tensors are the ONLY pruned initializers. Never globally sweep.
    used = {v for n in graph.node for v in n.input} | {o.name for o in graph.output} | {i.name for i in graph.input}
    _require(not replaced_weights & used, 'original replaced weight still referenced')
    removed = [t for t in graph.initializer if t.name in replaced_weights]
    retained = [t for t in graph.initializer if t.name not in replaced_weights]
    del graph.initializer[:]
    graph.initializer.extend(retained)
    return changed, dict(pruned_weight_names=sorted(replaced_weights),
                         pruned_initializer_count=len(removed),
                         pruned_initializer_serialized_bytes=sum(t.ByteSize() for t in removed),
                         transposed_weight_elements=sum(r['weight_shape'][0]*r['weight_shape'][1] for r in changed))


def transform_model(model, specialize_frames=98, gate_width=8):
    """Return independent CP1 candidate. Only the exact original is supported."""
    if type(specialize_frames) is not int or specialize_frames != FEATURE_FRAMES:
        raise ValueError('CP1_ONLY_EXPLICIT_FIXED_98_SUPPORTED')
    if type(gate_width) is not int or gate_width != GATE_WIDTH:
        raise ValueError('CP1_ONLY_GATE_WIDTH_8_SUPPORTED')
    original_bytes = model.SerializeToString()
    if _sha(original_bytes) != SOURCE_SHA256:
        raise ValueError('CP1_PINNED_ORIGINAL_MODEL_REQUIRED')
    # Strict original CAM graph validation and all-52 pool shape proof happen here.
    candidate, context_meta = context_transform(model, specialize_frames=FEATURE_FRAMES)
    gates = _tile_gates(candidate)
    projections, pruning = _pack_projections(candidate)
    onnx.checker.check_model(candidate, full_check=True)
    _require(model.SerializeToString() == original_bytes, 'original model mutated')
    original_pooling = [n.SerializeToString() for n in model.graph.node
                        if n.op_type in ('AveragePool', 'ReduceMean')]
    candidate_pooling = [n.SerializeToString() for n in candidate.graph.node
                         if n.op_type in ('AveragePool', 'ReduceMean')]
    _require(Counter(original_pooling) == Counter(candidate_pooling), 'pooling arithmetic changed')
    after_tensors = {t.name: t.SerializeToString() for t in candidate.graph.initializer}
    for tensor in model.graph.initializer:
        if tensor.name not in pruning['pruned_weight_names']:
            _require(after_tensors.get(tensor.name) == tensor.SerializeToString(), 'unrelated initializer changed')
    original_macs = 52*(128*64+64*32)*49
    candidate_macs = 52*(128*64+64*32)*GATE_WIDTH
    metadata = dict(revision='CP1', specialized_frames=FEATURE_FRAMES, gate_width=GATE_WIDTH,
        gate_tile=GATE_WIDTH, transformed_pointwise_layers=len(projections), transformed_gate_layers=gates['tiled_gates'],
        source_sha256=SOURCE_SHA256, candidate_sha256=_sha(candidate.SerializeToString()),
        original_nodes=len(model.graph.node), candidate_nodes=len(candidate.graph.node),
        removed_expansion_nodes=context_meta['removed_nodes'],
        projection_count=len(projections), projections=projections, **gates, **pruning,
        original_gate_macs=original_macs, candidate_gate_macs=candidate_macs,
        removed_gate_macs=original_macs-candidate_macs,
        gate_saved_macs=original_macs-candidate_macs,
        original_weights_value_changed=False,
        pruned_unused_original_weights=pruning['pruned_weight_names'],
        pruned_unused_original_weights_count=pruning['pruned_initializer_count'],
        projection_macs_unchanged=pruning['transposed_weight_elements']*49,
        weights_changed=False, pooling_changed=False, original_model_mutated=False,
        graph_layout_changed=True, dynamic_frames_preserved=False,
        bit_exact_claimed=False, arm_measured=False, numeric_performance_measured=False,
        explanation='55 fixed-RHS projections plus 52 gates on 8 repeated pooled positions; original model/weights remain baseline.')
    return candidate, metadata


def transform_file(source, output, metadata_path=None, specialize_frames=98, gate_width=8):
    source, output = Path(source).resolve(), Path(output).resolve()
    metadata_path = Path(metadata_path).resolve() if metadata_path is not None else output.with_suffix('.json')
    if source == output or metadata_path in (source, output):
        raise ValueError('CP1_INDEPENDENT_OUTPUT_PATHS_REQUIRED')
    if output.exists() or metadata_path.exists():
        raise FileExistsError('CP1_EXISTING_OUTPUT_PRESERVED')
    source_bytes = source.read_bytes()
    if _sha(source_bytes) != SOURCE_SHA256:
        raise ValueError('CP1_PINNED_ORIGINAL_MODEL_REQUIRED')
    candidate, metadata = transform_model(onnx.load_model_from_string(source_bytes), specialize_frames, gate_width)
    metadata.update(source=str(source), candidate=str(output), onnx_version=onnx.__version__)
    output.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as handle:
        handle.write(candidate.SerializeToString())
    with metadata_path.open('x', encoding='utf-8') as handle:
        json.dump(metadata, handle, indent=2, allow_nan=False)
        handle.write('\n')
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--metadata', type=Path)
    parser.add_argument('--frames', type=int, default=FEATURE_FRAMES)
    parser.add_argument('--gate-width', type=int, default=GATE_WIDTH)
    args = parser.parse_args()
    print(json.dumps(transform_file(args.source, args.output, args.metadata, args.frames, args.gate_width), indent=2))


if __name__ == '__main__':
    main()
