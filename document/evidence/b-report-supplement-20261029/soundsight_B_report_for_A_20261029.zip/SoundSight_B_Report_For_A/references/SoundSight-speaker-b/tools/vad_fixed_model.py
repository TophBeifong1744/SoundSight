"""VF1: pinned Silero branch specialization for the existing native 16k path.

PC-only model generation. Floating operations/weights stay unchanged. The graph
retains sr's ABI but callers must enforce sr==16000; it is not a generic VAD.
"""
import argparse
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path

import numpy as np
import onnx
from onnx import helper

SOURCE_SHA256='597d30b3ec076608d059477bb14cfeffdf951bf5cae370d38f65d33bbfe82004'
FIXED_SR=16000
INPUT_SHAPE=(1,576)
STATE_SHAPE=(2,1,128)
PREFIX='If_0_then_branch__Inline_0__'
BRANCHES={'If_0':'then_branch',PREFIX+'/decoder/If':'then_branch',
          PREFIX+'/decoder/If_1':'then_branch',PREFIX+'/decoder/rnn/If':'else_branch',
          PREFIX+'/decoder/rnn/If_1':'else_branch',PREFIX+'/decoder/rnn/If_4':'else_branch',
          PREFIX+'/If':'then_branch'}


def _sha(data):return hashlib.sha256(data).hexdigest()


def _require(condition,message):
    if not condition:raise ValueError('VF1_STRUCTURE: '+message)


def _flatten_selected(graph):
    """Copy selected lexical branches and prune only unreachable definitions."""
    _require(not graph.sparse_initializer,'sparse weights unsupported')
    nodes=[];initializers=[];seen=set();selected=[];copied=[]

    def flatten(g):
        if g is not graph:
            _require(not g.input and not g.sparse_initializer,'selected branch must use lexical inputs')
        for t in g.initializer:initializers.append(copy.deepcopy(t))
        for node in g.node:
            if node.op_type=='If':
                _require(node.name in BRANCHES and node.name not in seen,'unexpected or duplicate If '+node.name)
                _require(node.domain in ('','ai.onnx') and len(node.input)==1,'If operator contract')
                seen.add(node.name)
                attrs={a.name:a for a in node.attribute}
                _require(len(node.attribute)==2 and set(attrs)=={'then_branch','else_branch'},'If branch attributes')
                chosen=attrs[BRANCHES[node.name]]
                _require(chosen.type==onnx.AttributeProto.GRAPH,'If branch type')
                branch=chosen.g
                _require(len(branch.output)==len(node.output),'branch output arity')
                selected.append(dict(node=node.name,branch=BRANCHES[node.name],condition=node.input[0]))
                branch_index=len(selected)
                flatten(branch)
                for idx,(source,target) in enumerate(zip(branch.output,node.output)):
                    _require(source.name!=target,'branch output alias must be explicit')
                    nodes.append(helper.make_node('Identity',[source.name],[target],
                                                  name='VF1_bridge_%d_%d'%(branch_index,idx)))
            else:
                _require(not any(a.type in (onnx.AttributeProto.GRAPH,onnx.AttributeProto.GRAPHS)
                                 for a in node.attribute),'unhandled nested graph '+node.name)
                nodes.append(copy.deepcopy(node));copied.append(node.SerializeToString())
    flatten(graph)
    _require(seen==set(BRANCHES),'expected exactly seven flattened branches')
    definitions=[i.name for i in graph.input]+[t.name for t in initializers]
    definitions.extend(v for n in nodes for v in n.output if v)
    _require(len(definitions)==len(set(definitions)),'duplicate lexical tensor definition')
    named=[n.name for n in nodes if n.name]
    _require(len(set(named))==len(named),'duplicate nonempty node names')
    producers={v:index for index,n in enumerate(nodes) for v in n.output}
    needed=set();todo=[o.name for o in graph.output]
    while todo:
        value=todo.pop();index=producers.get(value)
        if index is not None and index not in needed:
            needed.add(index);todo.extend(nodes[index].input)
    kept=[n for index,n in enumerate(nodes) if index in needed]
    available={i.name for i in graph.input}|{t.name for t in initializers}
    for n in kept:
        _require(all(not v or v in available for v in n.input),
                 'unbound or forward lexical reference: '+n.name)
        available.update(n.output)
    _require(all(o.name in available for o in graph.output),'unbound output')
    originals=Counter(copied)
    _require(all(n.name.startswith('VF1_bridge_') or originals[n.SerializeToString()] for n in kept),
             'selected arithmetic/constant changed')
    return kept,initializers,dict(branches=selected,flattened_nodes_before_prune=len(nodes),
                                 pruned_unreachable_nodes=len(nodes)-len(kept),removed_if_count=len(seen))


def transform_model(original,fixed_sr=FIXED_SR,input_shape=INPUT_SHAPE,state_shape=STATE_SHAPE):
    """Return independent model and metadata; source hash fixes all predicates."""
    if type(fixed_sr) is not int or fixed_sr!=FIXED_SR:
        raise ValueError('VF1_ONLY_16000_SUPPORTED')
    if tuple(input_shape)!=INPUT_SHAPE or tuple(state_shape)!=STATE_SHAPE:
        raise ValueError('VF1_ONLY_FIXED_SHAPES_SUPPORTED')
    data=original.SerializeToString()
    if _sha(data)!=SOURCE_SHA256:raise ValueError('VF1_PINNED_ORIGINAL_REQUIRED')
    _require(not original.functions,'local functions unsupported')
    _require([i.name for i in original.graph.input]==['input','state','sr'],'input contract')
    _require([o.name for o in original.graph.output]==['output','stateN'],'output contract')
    onnx.checker.check_model(original)
    candidate=copy.deepcopy(original)
    graph=candidate.graph
    nodes,initializers,details=_flatten_selected(original.graph)
    del graph.node[:];graph.node.extend(nodes)
    del graph.initializer[:];graph.initializer.extend(initializers)
    del graph.value_info[:]
    del graph.quantization_annotation[:]
    contracts={'input':(onnx.TensorProto.FLOAT,list(INPUT_SHAPE)),
               'state':(onnx.TensorProto.FLOAT,list(STATE_SHAPE)),
               'sr':(onnx.TensorProto.INT64,[]),
               'output':(onnx.TensorProto.FLOAT,[1,1]),
               'stateN':(onnx.TensorProto.FLOAT,list(STATE_SHAPE))}
    for value in list(graph.input)+list(graph.output):
        dtype,shape=contracts[value.name]
        _require(value.type.tensor_type.elem_type==dtype,'tensor type')
        value.CopyFrom(helper.make_tensor_value_info(value.name,dtype,shape))
    _require(not any(n.op_type=='If' for n in graph.node),'If remains')
    onnx.checker.check_model(candidate,full_check=True)
    _require(original.SerializeToString()==data,'source mutated')
    metadata=dict(revision='VF1',source_sha256=SOURCE_SHA256,
        candidate_sha256=_sha(candidate.SerializeToString()),candidate_bytes=candidate.ByteSize(),
        candidate_nodes=len(graph.node),fixed_sr=FIXED_SR,input_shape=list(INPUT_SHAPE),state_shape=list(STATE_SHAPE),
        output_shape=[1,1],output_state_shape=list(STATE_SHAPE),unchanged_float_arithmetic=True,
        weights_changed=False,source_mutated=False,sr_guard_required=True,
        guard_required=True,state_present_predicate='tensor shape/numel, not numerical nonzero state',
        sr_abi_retained=True,sr_value_checked_inside_model=False,
        active_backend_changed=False,arm_validated=False,**details)
    return candidate,metadata


def validate_runtime_inputs(audio,state,sr):
    """Reference wrapper contract. Existing native vad_step hardcodes sr=16000."""
    if type(sr) is not int or sr!=FIXED_SR:raise ValueError('VF1_ONLY_16000')
    if not isinstance(audio,np.ndarray) or not isinstance(state,np.ndarray):raise ValueError('VF1_ARRAYS_REQUIRED')
    if audio.dtype!=np.float32 or audio.shape!=INPUT_SHAPE or state.dtype!=np.float32 or state.shape!=STATE_SHAPE:
        raise ValueError('VF1_SHAPE_OR_TYPE')
    if not np.isfinite(audio).all() or not np.isfinite(state).all():raise ValueError('VF1_NONFINITE')


def transform_file(source,output,metadata_path=None):
    source,output=Path(source).resolve(),Path(output).resolve()
    metadata_path=Path(metadata_path).resolve() if metadata_path is not None else output.with_suffix('.json')
    if source==output or metadata_path in (source,output):raise ValueError('VF1_INDEPENDENT_OUTPUT_PATHS_REQUIRED')
    if output.exists() or metadata_path.exists():raise FileExistsError('VF1_EXISTING_OUTPUT_PRESERVED')
    data=source.read_bytes()
    if _sha(data)!=SOURCE_SHA256:raise ValueError('VF1_PINNED_ORIGINAL_REQUIRED')
    candidate,meta=transform_model(onnx.load_model_from_string(data))
    meta.update(source=str(source),candidate=str(output),onnx_version=onnx.__version__)
    output.parent.mkdir(parents=True,exist_ok=True);metadata_path.parent.mkdir(parents=True,exist_ok=True)
    with output.open('xb') as f:f.write(candidate.SerializeToString())
    with metadata_path.open('x',encoding='utf-8') as f:json.dump(meta,f,indent=2);f.write('\n')
    return meta


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--metadata',type=Path)
    args=p.parse_args()
    print(json.dumps(transform_file(args.source,args.output,args.metadata),indent=2))


if __name__=='__main__':main()
