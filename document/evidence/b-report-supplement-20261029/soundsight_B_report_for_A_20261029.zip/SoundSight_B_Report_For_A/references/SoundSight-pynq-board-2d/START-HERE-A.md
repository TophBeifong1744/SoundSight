# A接续：PYNQ二维无舵机板测

交接日期：2026-10-22。用户决定本轮转交A继续，B停止新增测试和修改。
目标仍是二维定位稳定运行，不包含三维或舵机。本包是进度交接，**不是验收通过包**。

## A首先处理最后一次未保存日志

最后安排的是将最终日志写入 /dev/shm 的3000帧对照实验。
用户仅确认“最后一步日志没有保存到SD”，没有回传这次采集的结束输出。
因此不能确认是否完成3000帧、是否仍触发高水位，也不能确认文件已经丢失。

若板子尚未断电/重启，先只读检查，不先重启或加载bit：

```sh
pgrep -af 'run_buffered|run_capture|run_smp'
ls -lh /dev/shm/b-batch-ram-3000-001.jsonl
```

若采集已结束且文件存在，将原文件保留并复制到SD；目标文件独占新建，不覆盖已有证据：

```sh
python3 -c "import os,shutil; s=open('/dev/shm/b-batch-ram-3000-001.jsonl','rb'); d=open('/home/xilinx/SoundSight_PYNQ_Volume/b-batch-ram-3000-001.jsonl','xb'); shutil.copyfileobj(s,d); d.flush(); os.fsync(d.fileno()); d.close(); s.close(); print('COPY_TO_SD_OK')"
```

若提示目标已存在，先比较/检查，不覆盖。若采集仍在运行，先确认其状态，不并发启动另一采集。
若已重启或文件不存在，将此轮记为“原始日志不可用、结果未确认”，重新安排对照；不能补写通过结论。
未保存RAM文件前不要断电。旧SD上的所有实验文件都应保留。

## 当前板卡与软件

- PYNQ/Zynq xc7z020clg400-2，沿用A的SD镜像及原soundsight.bit/hwh。
- 工作目录 /home/xilinx/SoundSight_PYNQ_Volume；原 /home/xilinx/SoundSight_PYNQ 保留。
- Python /usr/local/share/pynq-venv/bin/python3，ARMv7 32-bit、Python3.8.2、GCC9.3.0。
- A交接源码版本标注 c63feab171d0a0b4e1f946d7d6172851ae2997db；源自
  soundsight_B_board_handoff.zip 内 soundsight_pynq_volume.zip，不能用旧远端覆盖。
- B新增两个PS产品文件修改已安装：software/ps/ram_queue.py、software/ps/run_buffered.py。
  标记 STORAGE_DIAG=SD_BATCH_V1，完整修改文件与测试随包提供。
- 自动备份 /home/xilinx/SoundSight_PYNQ_Volume/backup_sd_batch_v1_qp_pt2af。
- 仅这两个产品文件改变；C求解器、volume_gate.py、angle_filter.py、协议、bit/hwh均未改。
- 未将本轮修改推送GitHub。独立三维和旧STM32工作区未改，不属于本轮交付。
- 动作始终禁用：ACTUATOR_BOUND=0，不增加horizontal-motion等动作参数。

10月22日重新加载后的已确认值：

```text
LOADED=True  FCLK0_CTRL=0x400400  FCLK0_MHz=99.999999  FPGA_RST_CTRL=0x0
ID=0x5a5a2026  ABI=0x10001  STATUS=0x30000  FAULT=0  DROPS=0
```

最后未保存RAM实验前的已确认停止状态为STATUS=0x34000、FAULT=0x40、DROPS=0；
这不是RAM实验之后的新读数。只在读回并确认单独STOP位后按需清0x40，不自动清除其他故障。
重新上电后加载/时钟命令见SD-INSTALL.md；检查尚存RAM证据应在重启前完成。

## 已完成与未完成

| 项目 | 结果 | 限制 |
|---|---|---|
| ARM算法构建与迁移自测 | 已通过此前板端测试 | 不是实物角度精度验收 |
| PL→PS双BIST | 通过：0度ux=749295/uy=0/valid=1；拒绝ux=46831/uy=-171729/reason=3 | BIST不输出声学应用方向 |
| 原版1000帧持续有声 | 1000主帧+1尾帧，连续、零丢帧，50个窗口有效 | 参考角与源距离未确认；尾帧仅STOP |
| 原版1000帧安静 | 1000主帧+1尾帧，连续、零丢帧，零有效输出 | 环境含电脑风扇；尾帧仅STOP |
| 原版3000帧播放/暂停轮 | 2314帧触发高水位，已存帧连续、无故障/丢帧 | 用户更正：没有恢复播放，不能称完整on/off/on |
| SD_BATCH_V1 PC回归 | 64项通过 | 慢盘为注入模型 |
| SD_BATCH_V1板端安装与离线回归 | 安装成功，6项+24项OK | fake-mmio等软件模型，不是实际PL采集 |
| SD_BATCH_V1实际SD采集3000帧 | 2831帧触发高水位；连续、帧内fault=0、drops=0 | 仍未完成持续采集目标；本轮零有效方向 |
| 最后tmpfs最终日志对照 | 未确认，日志未保存到SD | 尚无控制台结果，不计通过 |
| 完整声音停止/恢复、多参考角 | 待做 | 当前不能宣称二维稳定运行验收完成 |

此前1000帧有效窗口的死区前角度约4.24..11.37度，实际目标更新3次。
没有明确参考角，不能给出绝对精度。临时音量门限7000并非通用标定值。

## 最新失败轮的关键证据

文件 b-batch-sound-3000-001.jsonl，用户统计显示已在项目目录落盘：

```text
STORAGE_DIAG=SD_BATCH_V1 BATCH_SIZE=8 BATCH_WAIT_MS=50.0 HIGH_WATER=48
DURABLE_FRAMES=2831 QUEUE_PEAK=49
consumed=2831 drained=0 max_service_ns=28985308
stop_reason=host_stop requested_frames=3000 host_stop_reason=queue_high_water
STORAGE_STATS={'batches':461,'records':2833,'max_batch':8,
               'total_save_ns':5251447312,'max_save_ns':476390644}
CAPTURE_INCOMPLETE=queue_high_water
FRAMES=2831 CONTIGUOUS=True DROPS=[0] FAULT_RECORDS=[]
REASONS={'below_volume_threshold':2070,'collecting_window':756,
         'insufficient_consensus':2,'insufficient_valid':3}
STATUS=0x34000 FAULT=0x40 DROPS=0
```

2833记录包括启动/结束事件，不是多出两个音频帧。
result峰48与最终峰49包含结束记录入队的差异，不能据此判定丢帧。
保存耗时含序列化、write/flush/fsync与调度等待；476ms不等于已测得纯fsync耗时。
当前空间检查：SD 29GB/已用6GB/剩余21GB；/dev/shm 501MB空闲；
内存1001MB/可用854MB，Swap511MB/使用0。SWAP_ACTIVE=True只代表启用，
不能推出采集时发生换页，当前读数也不能排除历史短时压力。

批量同步已工作，但未解决实际高水位；不能归咎为已确认的SD硬件故障，
也不能因2831大于2314就宣称性能提高（不是严格相同声源/时序对照）。
本轮2070帧低于门限，5个完整窗口均被拒绝；存储与声学有效率应分开定位。

## B修改的保存语义

默认最多8条记录合并write/flush/fsync，每批等待凑数最多50ms。
整批同步成功才删除对应RAM副本。容量64、高水位48、四条停止余量不变；
批次在途仍占容量，写失败保留整批及后续RAM记录，恢复可能重复须按session/ticket识别。
不把RAM入队ACK冒充SD耐久确认。断电可能丢失未同步的RAM记录。
高水位仍会STOP/排尾/保存，完整收尾后退出码2，避免被当成目标帧数完成。
原run_smp.py逐帧耐久入口不改。新统计仅在结束时打印，控制台输出也需留存。

PC确定性模型每次同步期间到来4条、目标240条：旧版60条/峰48触发保护，新版240条/峰12完成。
这只能证明该模式的改进，不替代当前实板失败事实。

## 建议A继续的顺序

1. 优先找回最后tmpfs日志及控制台输出；先核对是否存在finished事件、实际帧数、连续性、故障/丢帧。
2. 若最后实验无证据，保持同一声源/参数，重做“最终日志写SD”与“最终日志写tmpfs”的对照，
   tmpfs结果结束后立即复制到SD。两种模式都保留统计；不得仅凭文件存在判完成。
3. 若tmpfs通过而SD失败，针对存储路径补测write/flush/fsync分段耗时、队列随时间变化和系统I/O；
   若tmpfs也失败，查CPU0队列/文件处理、进程IPC和调度。不要只调高阈值掩盖积压。
4. 修正后先完成3000帧固定声音连续运行：consumed=3000、requested_frames正常结束、零丢帧、
   序号连续，正常帧无故障；尾帧允许预期STOP。保留实际持续时间和存储统计。
5. 再做完整播放/暂停/恢复，标记实际操作时间；确认静音清窗口、恢复后重新产生有效方向。
6. 确认阵列通道/坐标、零度和正负方向，用固定距离/音量及已知参考角测试正前/左/右，
   汇总有效率、角度偏差和波动。调门限需保留环境条件，不把无效帧当0度。
7. 汇总最终源码/参数/原始日志/启动步骤，明确本轮无舵机验收范围。

## 证据与包内文件

- evidence/sd-batch-arm-20261022/install-and-tests-uart.txt：用户实际附件原文。
- evidence/board-summary-20261022.md：聊天回传数值摘录，不是原始JSONL。
- software/ps/：两个完整修改文件；software/tests/：两个相关测试文件。
- changes-from-A.patch：相对A原交接包的差异，供审阅，不必重复应用到已安装板卡。
- soundsight_ps_sd_batch_v1.zip：原安装包，板卡已安装；其中报告是当时历史快照。
- SD-INSTALL.md：安装及原已验证加载命令；SD-BATCH-REPORT.md：开发测试记录。

本交接包不包含板端全部原始JSONL，A需从板上项目目录取回：
b-bist-pass-001.jsonl、b-bist-reject-001.jsonl、b-quiet-100-001/002.jsonl、
b-sound-100-001/002.jsonl、b-filter-sound-100-001.jsonl、b-filter-sound-1000-001.jsonl、
b-filter-quiet-1000-001.jsonl、b-filter-on-off-on-3000-001.jsonl、b-batch-sound-3000-001.jsonl。
最后b-batch-ram-3000-001.jsonl是否仍存在待现场检查。
