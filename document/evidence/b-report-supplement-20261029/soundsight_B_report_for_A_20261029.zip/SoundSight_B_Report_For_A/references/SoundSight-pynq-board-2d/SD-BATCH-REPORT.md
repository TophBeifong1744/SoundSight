# 二维无舵机板测：PS 保存队列修正

日期：2026-10-21；2026-10-22更新。状态：PC与板端离线验证完成，实际SD采集仍触发高水位，转交A继续。

最新：SD_BATCH_V1已安装且实际运行，3000帧目标只完成2831帧，queue_high_water停止。
保存2831帧连续、帧内故障0、丢帧0；停止后仅STOP。461次保存同步、2833条记录，
总保存时间5.251447312秒、最长单批476.390644ms。本轮零有效方向（2070帧低于门限）。
最后安排tmpfs最终日志对照，用户说日志未保存到SD，未回传结束结果，不能记为通过或确认丢失。
用户已要求将当前进度转交A，B停止新增实验；完整现态和后续入口见START-HERE-A.md。

2026-10-22更新：用户回传确认PYNQ安装成功（INSTALL_OK=SD_BATCH_V1），备份目录
/home/xilinx/SoundSight_PYNQ_Volume/backup_sd_batch_v1_qp_pt2af。
板端ARM离线测试6项/0.868s、24项/14.026s全部OK；模拟旧队列60条/峰48触发保护，
新队列240条/峰12完成。上述测试使用fake-mmio等模型，不是实际PL采集或SD持续吞吐验收。
原始回传保存于evidence/sd-batch-arm-20261022/install-and-tests-uart.txt。
上述离线测试后已恢复PL与100MHz时钟并完成身份核对；随后3000帧实板复测结果见本报告顶部更新。

基线为 A 的 soundsight_B_board_handoff.zip 内 soundsight_pynq_volume.zip，
对应 A 提供的源码版本 c63feab171d0a0b4e1f946d7d6172851ae2997db。
本目录为独立二维板测工作区。原交接包、旧 STM32 和独立三维工作区保持不动。

## 实板事实与结论边界

用户回传 b-filter-on-off-on-3000-001.jsonl 的统计：请求3000帧，消费和保存2314帧，
序号连续、drops=0、所有帧 fault=0。结束原因为 host_stop / queue_high_water，
结果记录 queue_peak=48，最终控制台峰值49（结束事件也占队列）。结束后 STATUS=0x34000、
FAULT=0x40、DROPS=0，仅剩停止标记。error=None 不等于采集目标完成。

用户最后更正：只完成播放与暂停，**没有恢复播放**。原文件名保留，不能据此宣称恢复识别通过。
这份记录是正确触发高水位保护且保存已消费数据的证据，不是3000帧连续验收通过。
本文件依据用户回传文本整理，不冒充已获得完整原始 JSONL。

先前1000帧有声：1000+1尾帧，连续、无丢帧，50个窗口有效；仅尾帧带STOP。
先前1000帧安静（有电脑风扇）：1000+1尾帧，连续、无丢帧，零有效方向；仅尾帧带STOP。
7000是当前环境的临时音量门限。距离、实测参考角尚不明确，不能据此给出定位精度结论。

## 修改

产品只改 software/ps/ram_queue.py 与 software/ps/run_buffered.py。

- 原实现每条记录 write/flush/fsync。新无动作入口默认最多8条合并一次同步，
  从首条待写开始等待最多50ms；未凑满也同步，关闭队列立即排尾。
- 整批同步成功后才逐条删除对应RAM文件并归还容量；写失败、flush失败、fsync失败时
  整批与后续记录都保留。失败恢复可能重复，继续使用 session/ticket 判断同一记录。
- 在途批次仍占队列；容量64、高水位48、四条停止余量不变。旧单条 RamQueue 调用仍兼容。
- 增加 STORAGE_DIAG=SD_BATCH_V1、STORAGE_STATS：成功同步批次/记录数、最大批次、
  保存总耗时与最大耗时。保存耗时包括序列化、write、flush、fsync，不是算法或纯fsync耗时。
- 高水位提前退出在完整保存后返回退出码2并打印 CAPTURE_INCOMPLETE，避免被当作完整运行成功。
- C算法、音量/角度筛选、门限、协议、bit/hwh和动作禁用条件未改；旧逐帧耐久入口不改。

这修正了可复现的逐条同步吞吐瓶颈。实际SD长尾延迟、调度与swap影响仍需板端统计区分；
不保证批量写盘可消除任意长时间的介质阻塞。50ms是主动收集批次的上限，不是SD完成时限。
保持原RAM保管策略：断电可能丢失尚未同步的数据。

## PC 实测

确定性模型：每次SD同步期间到来4条记录，容量64/高水位48，目标240条。
使用实际队列和JSONL写盘路径，注入同步期间的到帧；该模型不等于板卡速率测量。

| 实现 | 完成记录 | 同步次数 | 队列峰值 | 高水位停止 |
|---|---:|---:|---:|---|
| 原逐条同步 | 60 | 60 | 48 | 是 |
| 新批量同步 | 240 | 59 | 12 | 否 |

新增回归先在原实现失败，再在修改后通过。通过共64项：
批量保存6项，原队列/真实spawn及新增批量集成24项，角度筛选19项，音量门限15项。
包括磁盘写/flush/fsync失败保留、阻塞时容量不提前释放、部分尾批同步、
真实进程STOP/双槽排尾、高水位与满盘保护、连续帧和角度结果、无运动命令。

PC命令（工作目录为本目录）：

```text
D:/Python/python.exe -X utf8 -m unittest discover -s software/tests -p test_sd_batch.py -v
D:/Python/python.exe -X utf8 -m unittest discover -s software/tests -p test_buffered.py -v
D:/Python/python.exe -X utf8 -m unittest discover -s software/tests -p test_online_angle_filter.py -v
D:/Python/python.exe -X utf8 -m unittest discover -s software/tests -p test_volume_gate.py -v
```

预期 argparse 报错属于非法参数负例，以最后 OK 为准。

## 后续验收

安装、板端离线测试和PL恢复已完成。接续A先保全尚可能存在的tmpfs证据并定位积压，
随后用固定声源完成3000帧持续采集，检查 consumed=3000、stop_reason=requested_frames、
host_stop_reason=None、连续序号和零丢帧，尾帧仅可带预期STOP。
对照 STORAGE_STATS 与队列峰值。随后单独做完整播放/暂停/恢复播放并记录实际时序，
再做有参考角的多个位置测试。本轮始终不驱动舵机。
