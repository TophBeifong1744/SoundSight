# 用户聊天回传摘录（非原始JSONL）

此文件整理用户在本会话粘贴的数值，未从板卡直接读取原始文件。

## 配置恢复与身份

```text
DOWNLOAD_BEGIN
LOADED= True
FCLK0_CTRL= 0x400400
FCLK0_MHz= 99.999999
FPGA_RST_CTRL= 0x0
ID= 0x5a5a2026
ABI= 0x10001
STATUS= 0x30000
FAULT= 0x0
DROPS= 0
```

## SD_BATCH_V1 实际SD采集轮

命令：

```sh
sudo env XILINX_XRT=/usr /usr/local/share/pynq-venv/bin/python3 software/ps/run_buffered.py --hwh soundsight.hwh --output b-batch-sound-3000-001.jsonl --mode real --frames 3000 --min-level 7000 --angle-filter
```

用户回传：

```text
RAM_QUEUE_SWAP_ACTIVE= True
RAM_RECOVERY_DIR= /dev/shm/soundsight-vx6hq6_i
STORAGE_DIAG=SD_BATCH_V1 BATCH_SIZE= 8 BATCH_WAIT_MS= 50.0 HIGH_WATER= 48
DURABLE_FRAMES= 2831 QUEUE_PEAK= 49 RESULT= {'error': None, 'stats': {'consumed': 2831, 'drained': 0, 'max_service_ns': 28985308}, 'stop_reason': 'host_stop', 'requested_frames': 3000, 'host_stop_reason': 'queue_high_water', 'queue_peak': 48}
STORAGE_STATS= {'batches': 461, 'records': 2833, 'max_batch': 8, 'total_save_ns': 5251447312, 'max_save_ns': 476390644}
CAPTURE_INCOMPLETE=queue_high_water
FRAMES= 2831 CONTIGUOUS= True
DROPS= [0]
FAULT_RECORDS= []
REASONS= {'below_volume_threshold': 2070, 'collecting_window': 756, 'insufficient_consensus': 2, 'insufficient_valid': 3}
END_RECORD= {'event': 'finished', 'retention': 'ram_before_consume', 'host_pid': 655, 'host_cpu': 0, 'host_affinity': [0], 'error': None, 'stats': {'consumed': 2831, 'drained': 0, 'max_service_ns': 28985308}, 'stop_reason': 'host_stop', 'requested_frames': 3000, 'host_stop_reason': 'queue_high_water', 'queue_peak': 48}
STATUS= 0x34000
FAULT= 0x40
DROPS= 0
```

## 该轮结束后的系统空间

```text
Filesystem      Size  Used Avail Use% Mounted on
/dev/root        29G  6.0G   21G  23% /
tmpfs           501M     0  501M   0% /dev/shm
              total        used        free      shared  buff/cache   available
Mem:           1001         127         712           1         162         854
Swap:           511           0         511
```

## 最后内存最终日志对照：结果未知

下列命令仅是已给用户的实验步骤，**不是执行成功证据**：

```sh
sudo env XILINX_XRT=/usr /usr/local/share/pynq-venv/bin/python3 software/ps/run_buffered.py --hwh soundsight.hwh --output /dev/shm/b-batch-ram-3000-001.jsonl --mode real --frames 3000 --min-level 7000 --angle-filter --clear-faults 0x40
```

用户最终说明原文：“最后一步日志没有保存到SD，当前进度转接给A继续”。
没有该轮控制台RESULT/STORAGE_STATS或JSONL统计；完成帧数与当前设备状态未知。
检查和保全顺序见START-HERE-A.md。不得沿用上一轮0x40读数声称本轮仍仅STOP。
