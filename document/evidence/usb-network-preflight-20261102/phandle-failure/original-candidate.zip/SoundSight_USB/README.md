# 领航者 PYNQ 单 USB 数据线：待板测候选

目标：Windows 电脑 Type-C 接领航者 USB SLAVE，通过 USB 网络同时运行 SSH 与 WinSCP/SFTP；保留 DC 供电。首次配置继续使用原 USB UART。USB 网络尚未实板启用，下面是匹配本次采集系统的候选，不是所有 PYNQ 镜像通用安装器。

2026-11-02 用户明确：当前应用 `.bit/.hwh` 已由 B 修改，不能视为原始版本。本次保留板端当前 B 版，不替换或回退应用 `.bit/.hwh`；采集包没有包含它们，未核验其内部配置。候选也不改 `BOOT.BIN`、`IMAGE.UB`、`BOOT.SCR` 或现有应用入口。后续必须在实际 B 版程序下验证连接共存。

## 使用候选包

文件：`release/output/soundsight_usb_network.zip`，根目录 `SoundSight_USB`。包含两个 ARM 模块、两阶段 DTBO、源代码/许可证、Python 配置助手、校验清单和本文。不包含应用位流、声纹模型或替换内核。两模块针对 `5.4.0-xilinx-v2020.2` 的实际配置和符号表构建；使用 GCC 9.2.1，原内核 GCC 9.2.0，已检查编译配置语义与符号 CRC，仍需实际加载确认。

### 1. 拷包与接线（第一次保留串口）

1. 退出正在运行的应用，串口执行 `sudo poweroff`。系统停机后断电，取出 SD 卡。
2. Windows 将 ZIP 复制到 SD 卡可见分区根目录。不要覆盖启动文件或 B 版应用文件。
3. DC 和 USB 全部断开时，核对实板 P4 的针脚标记，跳帽设为 Slave：**1–3、2–4**，不是 1–2、3–4。仓库资料为领航者板规格书 V1.2 §3.19；实板标记不一致时停止改接。
4. 插回 SD 卡，接匹配的 DC 适配器。原 USB UART 接电脑，另用支持数据的 C-to-C 线连接电脑与板卡 **USB SLAVE**。不要接四个 USB HOST 口。首次验证用两条数据线，成功并配置自动启动后只保留 SLAVE 数据线。

### 2. 解压和只读预检

以下每个代码框都是单行，在原 `xilinx@pynq` 串口发送；不在 Windows PowerShell 中执行。若目标目录已存在，首条命令不会覆盖，先核对旧目录来源。

```bash
test ! -e /home/xilinx/SoundSight_USB && python3 -m zipfile -e /boot/soundsight_usb_network.zip /home/xilinx
```

```bash
sudo python3 /home/xilinx/SoundSight_USB/usb_network.py check
```

预期 `CHECK_OK`。该步骤只读匹配内核配置、符号表、包内容、原启动文件、USB 状态及 MIO；检查 SSH 单元存在，并拒绝与现有路由重叠的子网。若不通过，保留报错，不强制绕过校验。

### 3. 本次启动临时启用

仅在按第1步完成 Slave 跳帽及 DC 供电后执行。此命令会配置 USB MIO、脉冲复位 USB PHY、加载 USB 模块和设置 USB 网络；不操作 FPGA 位流或执行器。

```bash
sudo python3 /home/xilinx/SoundSight_USB/usb_network.py start --confirm-slave
```

预期 `USB_READY board=192.168.77.2/24 interface=usb0`（网卡名称以实际输出为准）。没有此输出就停止，不重复 start；从 UART 保存下面输出，再正常重启恢复运行时 USB 配置：

```bash
sudo dmesg | tail -n 100
```

```bash
sudo python3 /home/xilinx/SoundSight_USB/usb_network.py status
```

默认不写开机服务；手动启用失败后可以用 `sudo reboot` 正常重启回原状态。不在线移除 overlay、不反复复位正在工作的控制器。如果已按第6步启用服务，必须先禁用服务再重启。

### 4. Windows 设置虚拟网卡

打开设备管理器，预期出现 USB Ethernet/RNDIS 或 Remote NDIS 网络适配器。包提供 Microsoft OS 描述符用于驱动匹配，但实际 Windows 自动安装尚未验证。

如果新出现的 RNDIS 设备有黄色感叹号，可在该设备上选择“更新驱动程序→浏览我的电脑→让我从可用驱动程序列表中选取”，若列表提供 Microsoft 的 Remote NDIS Compatible Device，则使用它。不能把原 CH340 串口强行换成网络驱动。如果系统不提供兼容项，记录新设备硬件 ID 和 Windows 版本，不下载来源不明的 INF、不关闭驱动签名检查。

`Win+R` 输入 `ncpa.cpl`，找到这张新 USB 网卡，在属性的 IPv4 中设置：

| 字段 | 值 |
|---|---|
| IP | `192.168.77.1` |
| 子网掩码 | `255.255.255.0` |
| 默认网关 | 留空 |
| DNS | 留空 |

仅改 USB 网卡，保留 Wi-Fi/普通网卡。显示“无 Internet”是正常的，此连接只用于本机与开发板通信。无需关闭防火墙或开网络共享。

### 5. SSH 与 WinSCP

Windows PowerShell 执行：

```powershell
Test-NetConnection 192.168.77.2 -Port 22
```

应看到 `TcpTestSucceeded : True`。然后：

```powershell
ssh xilinx@192.168.77.2
```

使用板上当前账户密码。首次主机指纹可与 UART 执行 `sudo ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub` 的结果核对；不要忽略身份变更提示。Windows 若没有 ssh 命令，可用现有 PuTTY/MobaXterm 的 SSH 会话。

WinSCP 新建站点：协议 **SFTP**、主机 `192.168.77.2`、端口 `22`、用户 `xilinx`、密码为当前板端密码。上传到 `/home/xilinx/` 下的自有目录，不覆盖启动文件或 B 的当前应用。可以同时开 SSH 终端和 WinSCP。

先传一个无关的测试文件，用 Windows `Get-FileHash -Algorithm SHA256` 与板端 `sha256sum` 比较。随后按当前 B 版既有方式做关轴运行，确认 USB 连接保持；USB传包成功不能代替 B 版应用联合验证。

### 6. 确认 SSH、SFTP 均通过后，才启用开机服务

在板端 SSH 或 UART 发送：

```bash
sudo python3 /home/xilinx/SoundSight_USB/usb_network.py enable-service
```

助手要求本轮 start 成功且电脑已经配置 USB 设备，复制已校验包到 `/opt/soundsight-usb-network`，注册专用服务；不改原应用服务，不自动重启。中断后同包可重试，不覆盖不同版本或他人服务。

正常重启验证：

```bash
sudo reboot
```

确认开机后再次能 SSH 和 WinSCP，再拔掉 USB UART 通信线。日常使用保留 **DC适配器＋USB SLAVE这一根电脑数据线**。P4保持Slave；改回Host前先禁用服务。

回退（从 UART 执行）：

```bash
sudo systemctl disable soundsight-usb-network.service
```

```bash
sudo reboot
```

没有在线移除 DT overlay 的 stop 命令。禁用服务再重启即可恢复原运行时USB/MIO状态；正常关机、断电后才改跳帽。包和服务文件保留便于排错，不自动删除用户资料。

## 2026-11-02 用户串口结果

- Linux `5.4.0-xilinx-v2020.2`，用户 `xilinx`。
- `/sys/class/udc` 为空；两个控制器 `/amba/usb@e0002000`、`/amba/usb@e0003000` 均为 `status=disabled`，没有 `dr_mode`，`phy_type=ulpi`。
- `CONFIG_USB_CHIPIDEA=y`、`CONFIG_USB_CHIPIDEA_UDC=y`、`CONFIG_USB_GADGET=y`。
- `CONFIG_USB_LIBCOMPOSITE=m`、`CONFIG_USB_CONFIGFS=m`，ConfigFS mass-storage 已启用。
- `CONFIG_USB_ETH`、`CONFIG_USB_CONFIGFS_RNDIS`、ECM、ACM 均未启用。`g_ether` 不存在；已找到 `libcomposite.ko`。
- build 目录有 680298 字节的 `Module.symvers`；`ether.c`、`f_rndis.c`、`u_ether.c` 不存在。不能把已安装头文件当成完整厂商内核源码，也不能仅凭相同 uname 字符串认定外来模块 ABI 匹配。
- `/boot` 是 `/dev/mmcblk0p1`，vfat。含 `BOOT.BIN`、`BOOT.SCR`、`IMAGE.UB`、`REVISION`、`boot.py`；不能仅因文件名判断 FIT 内设备树或 boot script 的实际加载方式。
- 用户启动参数：`root=/dev/mmcblk0p2 rw earlyprintk rootfstype=ext4 rootwait devtmpfs.mount=1 uio_pdrv_genirq.of_id="generic-uio" clk_ignore_unused`。
- 实际 SLCR：MIO9=`0x1601`；MIO28～39全为`0x1201`，说明仍为GPIO复用，Bank500/501分别是LVCMOS33/LVCMOS18。

结论：需要补齐网络 Gadget 功能，并配置实际接线对应的 USB 控制器、PHY 与复位。优先评估匹配现有内核的模块增补，不直接重刷系统，不同时盲目启用两个控制器，不先修改启动文件。

## 已完成的输入采集

正式助手：`tools/collect_usb_gadget_inputs.py`，Python 3.8 标准库。仅读取指定启动文件、运行设备树、内核配置、已安装 build 目录及系统版本/挂载信息；唯一写入为新 ZIP，已有输出拒绝覆盖。不执行构建、加载模块、网络设置、复位、FPGA 下载或执行器动作。不会采集用户主目录、SSH 密钥或声纹数据。

把脚本通过现有网络，或正常关机后经 Windows 读卡器，复制到 SD 卡 Windows 可见启动分区根目录。重新启动后，在原串口发送单行命令：

```bash
sudo python3 /boot/collect_usb_gadget_inputs.py
```

默认生成 `/boot/soundsight_usb_inputs.zip`。正常关机并等系统停机后断电取卡，把 ZIP 复制回电脑；有现成网络也可直接取回。采集含部分失败时返回 2，ZIP 内 `manifest.json` 登记失败；仍需交回分析，不能称输入完整。磁盘满等中断可能留下不完整 ZIP，不自动覆盖。输出目录需至少 128 MiB 可用空间；输入有单文件 64 MiB、总计 512 MiB 上限，不保证压缩输出固定大小。

本板启动分区约130MB，最初因剩余空间小于128MiB的保守检查而拒绝输出，后改到`/home/xilinx/soundsight_usb_inputs.zip`成功生成22MB包，再复制回启动分区。收件后已核对启动包、实际PHY/复位、MIO读回、内核配置/符号并生成上文候选。采集脚本本身仍不是USB网卡安装器。

## 最终接线与网络目标（尚待配置）

仓库板卡规格书 V1.2 第34～35页：USB3320 经 P4 选择连接 USB SLAVE 或 USB HUB；Slave 为 1–3、2–4 短接。断电后核对实板版次及标记再操作。USB SLAVE 与 CH340 USB UART 是不同接口；选择 Slave 后同一路控制器不再服务四口 HUB。

目标采用 Windows 可用的 USB 网络，SSH 和 WinSCP 使用同一板端 IP 与已有账户。USB 网络不能替代 Linux 启动前的 UART 日志，亦不等于 JTAG。已存在 USB 供电重启记录，继续使用匹配 DC 适配器。

采集包已收件，12202项文件完整校验；13个提示全是跳过DTC include-prefixes符号链接。最终包尚未实板加载或验证枚举/SSH/SFTP。离线结果和剩余验证见 `evidence/usb-network-preflight-20261102/README.md`。
