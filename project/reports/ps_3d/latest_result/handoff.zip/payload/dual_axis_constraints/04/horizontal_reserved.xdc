# Only the explicit horizontal preparation recipe adds this constraint file.
# J4 pin 6 = U7, Bank 13. RTL ties the reserved vertical output LOW.
# Horizontal J4 pin 5 = V7 is set in the copied project's board_pins.xdc.
set_property PACKAGE_PIN W16 [get_ports servo_vertical_pwm]
set_property IOSTANDARD LVCMOS33 [get_ports servo_vertical_pwm]
set_property DRIVE 4 [get_ports servo_vertical_pwm]
set_property SLEW SLOW [get_ports servo_vertical_pwm]
