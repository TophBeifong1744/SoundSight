PORTABLE SOURCE HANDOFF
project.tcl: full project recreation entry; recipe.tcl: native project properties.
payload/: registered RTL, constraints, memory files, BD and top-level IP configuration.
bd/: separate readable BD/PS/IP Tcl recipes (not an additional build step).
source_files.txt: package-relative source inventory.
Use the same Vivado version. Copy this entire directory to a fresh location.
In an empty Vivado session source project.tcl. Synthesis and implementation are manual.
This export does not include bit/HWH/XSA or prove successful reconstruction/STA.
Unresolved machine paths, external dependencies and binary sources stop export.
