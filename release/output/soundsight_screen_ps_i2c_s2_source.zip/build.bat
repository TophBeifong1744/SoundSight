@echo off
setlocal
rem 使用确认的工具根目录，只修改当前进程PATH。
if not defined XILINX_VIVADO set "XILINX_VIVADO=D:\AMD\2025.2\Vivado"
set "PATH=%XILINX_VIVADO%\bin;%PATH%"
where vivado.bat >nul 2>nul
if errorlevel 1 exit /b 2
pushd "%~dp0"
call vivado.bat -mode batch -source "%~dp0build.tcl" -log "%~dp0build.log" -journal "%~dp0build.jou" -tclargs %*
set "ss_exit=%ERRORLEVEL%"
popd
exit /b %ss_exit%
