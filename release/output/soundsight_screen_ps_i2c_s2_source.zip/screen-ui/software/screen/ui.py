"""SoundSight 800x480 touch UI. Default screen selftest, no motion commands."""
import argparse
import json
import os
from pathlib import Path
import signal
import sys
import time

from backend import Backend


class UI:
    def __init__(self, backend):
        self.backend = backend
        self.page, self.mode, self.axes = 'HOME', 'SOUND', 'off'
        self.message, self.touch_text = '', 'Touch the four corners; coordinates appear here'
        self.buttons, self.dirty, self.down = [], True, False
        self.user_index, self.setting_index = 0, 0
        self.draft = dict(backend.cache)
        self.last_generation = -1
        self.touch_count = 0

    def action(self, action):
        b = self.backend
        try:
            if action == 'STOP':
                b.stop()
                self.axes = 'off'
            elif action.startswith('PAGE:'):
                self.page = action[5:]
            elif b.busy:
                self.message = 'Wait for confirmed STOP before changing mode/settings'
            elif action == 'START':
                b.start(self.mode, self.axes)
            elif action == 'MODE':
                self.mode = 'SPEAKER' if self.mode == 'SOUND' else 'SOUND'
                self.axes = 'off'
            elif action == 'AXES':
                choices = ['off', 'horizontal', 'vertical', 'both'] if b.motion and b.control else ['off']
                self.axes = choices[(choices.index(self.axes)+1) % len(choices)]
            elif action == 'ACK':
                b.acknowledge()
                self.axes = 'off'
                self.draft = dict(b.cache)
            elif action == 'STATUS':
                b.command('status')
            elif action == 'USER_NEXT':
                self.user_index = (self.user_index+1) % len(b.cache['profiles'])
            elif action == 'USER_SELECT':
                b.command('speaker-select', b.cache['profiles'][self.user_index])
                self.axes = 'off'
                self.message = 'Selection clears threshold. Run score-only before setting a new gate.'
            elif action == 'USER_VERIFY':
                b.command('speaker-list')
            elif action == 'FIELD':
                self.setting_index = (self.setting_index+1) % 5
            elif action in ('PLUS', 'MINUS'):
                key = ['level', 'window', 'minimum', 'threshold', 'ttl'][self.setting_index]
                step, low, high = dict(level=(500, 1, 16777215), window=(1, 1, 100),
                                       minimum=(1, 1, 100), threshold=(.05, -1, 1), ttl=(.5, .1, 30))[key]
                value = self.draft[key]
                if value is None:
                    value = 0.
                self.draft[key] = max(low, min(high, round(value + step*(1 if action == 'PLUS' else -1), 4)))
            elif action == 'APPLY':
                key = ['level', 'window', 'minimum', 'threshold', 'ttl'][self.setting_index]
                if key == 'level':
                    b.command('level', self.draft['level'])
                elif key in ('window', 'minimum'):
                    b.command('filter', self.draft['window'], self.draft['minimum'])
                elif key == 'ttl':
                    b.command('speaker-config', '--ttl', self.draft['ttl'])
                elif self.draft['threshold'] is not None:
                    b.command('speaker-config', self.draft['threshold'])
                else:
                    raise ValueError('Use +/- to choose an explicit trial threshold')
            elif action == 'DISABLE':
                b.command('speaker-config', '--disable')
                self.axes = 'off'
        except Exception as exc:
            self.message = str(exc)
        self.dirty = True

    def touch(self, points):
        if points is None:
            return
        if not points:
            self.down = False
            return
        x, y = points[0]
        self.touch_count += 1
        self.touch_text = 'Touch x=%d y=%d contacts=%d reports=%d' % (x, y, len(points), self.touch_count)
        # 一次按压只触发一次；不自动重复 START/轴选择/配置保存。
        if not self.down and len(points) == 1:
            for rect, action in reversed(self.buttons):
                if rect[0] <= x < rect[2] and rect[1] <= y < rect[3]:
                    self.action(action)
                    break
        self.down = True
        self.dirty = True

    def tick(self):
        self.backend.tick()
        if self.last_generation != self.backend.generation:
            if self.backend.state in ('IDLE', 'ERROR'):
                self.axes = 'off'
                self.draft = dict(self.backend.cache)
            self.last_generation = self.backend.generation
            self.dirty = True

    def render(self):
        from PIL import Image, ImageDraw, ImageFont
        im = Image.new('RGB', (800, 480), '#0b1423')
        draw = ImageDraw.Draw(im)
        try:
            normal = ImageFont.truetype('DejaVuSans.ttf', 17)
            large = ImageFont.truetype('DejaVuSans.ttf', 28)
        except OSError:
            try:
                normal, large = ImageFont.load_default(size=17), ImageFont.load_default(size=28)
            except TypeError:
                normal = large = None

        def text(x, y, value, color='#e6edf7', big=False, limit=88):
            value = str(value).encode('ascii', errors='replace').decode()[:limit]
            font = large if big else normal
            if font:
                draw.text((x, y), value, fill=color, font=font)
            else:
                # 无额外字体时放大 Pillow 自带位图字体，不分发 Windows 字体。
                small = Image.new('RGBA', (max(1, len(value))*7, 13), (0, 0, 0, 0))
                ImageDraw.Draw(small).text((0, 0), value, fill=color, font=ImageFont.load_default())
                enlarged = small.resize((small.width*2, 26), Image.NEAREST)
                im.paste(enlarged, (x, y), enlarged)

        def button(rect, label, action, color='#21354f'):
            draw.rectangle(rect, fill=color)
            text(rect[0]+12, rect[1]+12, label, limit=32)
            self.buttons.append((rect, action))

        b, c = self.backend, self.backend.cache
        self.buttons = []
        text(20, 12, 'SOUNDSIGHT', '#53d8cc', big=True)
        text(260, 20, 'DEMO / NO HARDWARE' if b.demo else ('CONTROL' if b.control else 'SCREEN + TOUCH SELFTEST'))
        text(20, 56, '%s  |  %s  |  AXES %s' % (self.mode, b.state, self.axes.upper()), '#f5cd75')
        for n, page in enumerate(('HOME', 'USERS', 'SETTINGS', 'DIAGNOSTICS')):
            button((20+n*195, 91, 200+n*195, 139), page, 'PAGE:'+page,
                   '#236b75' if self.page == page else '#21354f')
        if self.page == 'HOME':
            text(24, 157, 'Acoustic follow' if self.mode == 'SOUND' else 'Speaker gate / score_ttl_v2', big=True)
            text(24, 200, 'Identity gate OFF' if self.mode == 'SOUND' else 'Pass TTL starts at inference completion')
            text(24, 231, 'User: %s   threshold: %s   TTL: %ss' % (c['target'] or '(not selected)', c['threshold'], c['ttl']))
            text(24, 260, 'Level: %s   filter: %s / %s' % (c['level'], c['minimum'], c['window']))
            button((24, 298, 244, 351), 'Change mode', 'MODE')
            button((260, 298, 520, 351), 'Axes: '+self.axes, 'AXES')
            text(551, 270, 'R     G     B', '#a7bdd5')
            for n, color in enumerate(('#ff0000', '#00ff00', '#0000ff')):
                draw.rectangle((551+n*69, 298, 614+n*69, 351), fill=color)
            text(24, 361, b.note, '#a7bdd5', limit=78)
        elif self.page == 'USERS':
            self.user_index %= len(c['profiles'])
            text(24, 160, 'Current: '+str(c['target'] or '(none)'), big=True)
            text(24, 205, 'Candidate: '+c['profiles'][self.user_index])
            text(24, 236, 'Local names only. SELECT runs original profile validation.')
            text(24, 264, 'Selecting a user clears the old threshold.', '#f5cd75')
            button((24, 300, 215, 353), 'Next user', 'USER_NEXT')
            button((231, 300, 447, 353), 'SELECT user', 'USER_SELECT')
            button((463, 300, 755, 353), 'Validate / list', 'USER_VERIFY')
        elif self.page == 'SETTINGS':
            key = ['level', 'window', 'minimum', 'threshold', 'ttl'][self.setting_index]
            text(24, 157, 'Edit: %s = %s' % (key, self.draft[key]), big=True)
            text(24, 201, 'Saved: %s | applies only to next session' % c[key])
            text(24, 230, 'Trial threshold is not qualified recognition.', '#f5cd75')
            button((24, 266, 226, 318), 'Next field', 'FIELD')
            button((242, 266, 325, 318), '-', 'MINUS')
            button((341, 266, 424, 318), '+', 'PLUS')
            button((440, 266, 755, 318), 'APPLY current field', 'APPLY')
            button((24, 330, 330, 382), 'DISABLE speaker gate', 'DISABLE')
        else:
            text(24, 151, self.touch_text, '#53d8cc')
            text(24, 181, 'Actual CLI output (bounded, unparsed):', '#a7bdd5')
            for n, line in enumerate(list(b.lines)[-4:]):
                text(24, 208+n*25, line, limit=78)
            button((24, 325, 250, 377), 'Read status', 'STATUS')
            button((266, 325, 575, 377), 'Acknowledge / reload', 'ACK')
        # STOP 固定位置覆盖所有页面，配置状态不影响其可达性。
        draw.rectangle((0, 390, 800, 480), fill='#101f32')
        text(20, 394, self.message or b.note, '#f5cd75', limit=76)
        button((20, 426, 255, 478), 'START selected mode' if b.control else 'SELFTEST / axes OFF',
               'START', '#235748')
        button((275, 426, 780, 478), 'STOP / AXES OFF', 'STOP', '#9a3545')
        self.dirty = False
        return im


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    p.add_argument('--demo', action='store_true', help='Offline PNG; no hardware or subprocesses')
    p.add_argument('--demo-window', action='store_true', help='Offline interactive Tk window')
    p.add_argument('--screenshot', type=Path, default=Path('screen-preview.png'))
    p.add_argument('--page', choices=['HOME', 'USERS', 'SETTINGS', 'DIAGNOSTICS'], default='HOME')
    p.add_argument('--mode', choices=['SOUND', 'SPEAKER'], default='SOUND')
    p.add_argument('--control', action='store_true', help='Enable existing CLI via explicit touch START')
    p.add_argument('--enable-motion', action='store_true', help='Allow explicit axis selection; boot still OFF')
    p.add_argument('--frames', type=int, default=1000, help='Session frame bound, 1..100000')
    p.add_argument('--seconds', type=float, default=60., help='Screen lifetime; 0 for interactive indefinite')
    p.add_argument('--swap-xy', action='store_true')
    p.add_argument('--invert-x', action='store_true')
    p.add_argument('--invert-y', action='store_true')
    return p


def demo_window(ui):
    import tkinter as tk
    from PIL import ImageTk
    window = tk.Tk()
    window.title('SoundSight S1 - OFFLINE DEMO')
    window.resizable(False, False)
    label = tk.Label(window)
    label.pack()
    label.bind('<ButtonPress-1>', lambda event: ui.touch([(event.x, event.y)]))
    label.bind('<ButtonRelease-1>', lambda event: ui.touch([]))

    def update():
        ui.tick()
        if ui.dirty:
            photo = ImageTk.PhotoImage(ui.render())
            label.configure(image=photo)
            label.image = photo
        window.after(200, update)
    update()
    window.mainloop()


def main(argv=None):
    args = parser().parse_args(argv)
    import math
    if not 1 <= args.frames <= 100000 or not math.isfinite(args.seconds) or args.seconds < 0:
        raise ValueError('Use frames 1..100000 and finite seconds >= 0')
    if args.enable_motion and not args.control:
        raise ValueError('--enable-motion requires --control')
    try:
        import PIL
        import numpy
    except ImportError as exc:
        print('DEPENDENCY_MISSING: %s. No downloads or hardware access performed.' % exc, file=sys.stderr)
        return 2
    print('SCREEN_S2 transport=PS_I2C0_EMIO_LINUX Python=%s Pillow=%s numpy=%s' %
          (sys.version.split()[0], PIL.__version__, numpy.__version__))
    offline = args.demo or args.demo_window
    backend = Backend(args.root, args.control, args.enable_motion, demo=offline, frames=args.frames)
    ui = UI(backend)
    ui.page, ui.mode = args.page, args.mode
    if offline:
        ui.render().save(args.screenshot)
        print('OFFLINE_SCREENSHOT='+str(args.screenshot.resolve())+' HARDWARE_ACTIONS=0')
        if args.demo_window:
            demo_window(ui)
        return 0
    if os.name != 'posix':
        raise RuntimeError('Hardware screen requires Linux/PYNQ; use --demo on PC')
    import fcntl
    from hardware import open_overlay, ScreenGPIO, Touch, Display, wait_until
    from linux_i2c import LinuxI2C
    # 单独的屏幕所有者锁允许原运行时拥有采集锁；禁止第二个 UI 使用 DMA。
    owner = open('/tmp/soundsight-screen-owner.lock', 'a')
    fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
    display, gpio, bus = None, None, None
    quit_requested = [False]

    def request_exit(signum, frame):
        quit_requested[0] = True
        backend.stop()
    signal.signal(signal.SIGINT, request_exit)
    signal.signal(signal.SIGTERM, request_exit)
    result = 0
    try:
        overlay, mmio, allocate, np = open_overlay(args.root)
        # 先确认内核所有权和打开 fd，再进行任何触摸 GPIO 复位或探测。
        bus = LinuxI2C()
        print('PS_I2C_READY='+json.dumps(bus.details, sort_keys=True), flush=True)
        gpio = ScreenGPIO(mmio(0x41200000, 0x1000))
        display = Display(mmio(0x43000000, 0x1000), gpio, allocate, np)
        display.start(allocate)
        # 视频输出锁定依赖有效 AXI 视频流，必须先启动 VDMA 再等待锁定。
        wait_until(gpio.locked, 1., 'Screen video output timing lock not asserted')
        touch = Touch(bus, gpio,
                      args.swap_xy, args.invert_x, args.invert_y)
        controller = touch.probe()
        print('TOUCH='+controller, flush=True)
        ui.message = controller
        display.present(ui.render())
        gpio.backlight(True)
        print('SCREEN_READY=1 CURRENT_FRAME_ACK=%d AXES=off CONTROL=%d' %
              (display.active, int(args.control)), flush=True)
        started, last_render, last_health = time.monotonic(), time.monotonic(), 0.
        while not quit_requested[0]:
            now = time.monotonic()
            if args.seconds and now-started >= args.seconds:
                break
            ui.tick()
            ui.touch(touch.poll())
            if now-last_health >= .1:
                display.health()
                last_health = now
            interval = .5 if backend.busy else .2
            if ui.dirty and now-last_render >= interval:
                display.present(ui.render())
                last_render = time.monotonic()
            time.sleep(.02)
    except Exception as exc:
        result = 1
        print('SCREEN_STOP: %s: %s' % (type(exc).__name__, exc), file=sys.stderr, flush=True)
    finally:
        # 异常或退出先撤销运行时动作，等待真实退出；绝不静默强杀后重启。
        backend.stop()
        if gpio:
            try:
                gpio.backlight(False)
            except Exception as exc:
                print('BACKLIGHT_OFF_UNCONFIRMED: '+str(exc), file=sys.stderr, flush=True)
        last_report = 0.
        while backend.busy:
            backend.tick()
            if time.monotonic()-last_report > 5:
                print('EXIT_PENDING: '+backend.note, flush=True)
                last_report = time.monotonic()
            time.sleep(.05)
        if display:
            while not display.close():
                print('DMA_STOP_UNCONFIRMED: retaining buffers, backlight OFF; do not reprogram/kill', flush=True)
                time.sleep(1)
        if bus:
            bus.close()
        fcntl.flock(owner, fcntl.LOCK_UN)
        owner.close()
    return result


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print('SCREEN_ERROR: %s: %s' % (type(exc).__name__, exc), file=sys.stderr)
        raise SystemExit(1)
