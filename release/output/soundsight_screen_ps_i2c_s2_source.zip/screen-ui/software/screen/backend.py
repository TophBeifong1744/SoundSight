"""Single subprocess owner; all runtime operations use existing argument-list CLI."""
from collections import deque
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def read_json(path, default):
    if not path.exists():
        return default
    if path.stat().st_size > 65536:
        raise ValueError('Oversized local configuration: ' + path.name)
    value = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value, dict):
        raise ValueError('Expected configuration object: ' + path.name)
    return value


class Backend:
    def __init__(self, root, control=False, motion=False, demo=False, frames=1000):
        self.root = Path(root).resolve()
        self.control, self.motion, self.demo, self.frames = control, motion, demo, frames
        self.proc, self.pgid, self.pending = None, None, b''
        self.state, self.note, self.operation = 'IDLE', 'Axes OFF. Tap START explicitly.', ''
        if not control:
            self.note = 'Screen/touch selftest. Runtime START and configuration are disabled.'
        self.lines = deque(maxlen=16)
        self.started = self.stopping = 0.
        self.generation = 0
        self.cache = {}
        self.reload()

    @property
    def busy(self):
        return self.proc is not None

    def reload(self):
        # 仅读小型本地配置，不读取或导出模型、嵌入向量、个人录音。
        root = self.root
        settings = read_json(root/'settings.local.json', {})
        gate = read_json(root/'speaker-follow.local.json', {})
        selected = read_json(root/'speaker-target.local.json', {})
        profiles = ['P01']
        for path in sorted((root/'speaker-profiles').glob('*/profile.json')):
            name = 'P02' if path.parent.name == 'P02-v1' else path.parent.name
            if len(profiles) < 128 and name not in profiles:
                profiles.append(name)
        self.cache = dict(level=settings.get('min_level', 7000),
                          window=settings.get('window_frames', 20),
                          minimum=settings.get('min_valid', 12),
                          threshold=gate.get('threshold'), ttl=gate.get('permit_seconds', 3.),
                          target=selected.get('target_id'), profiles=profiles,
                          calibration=read_json(root/'servo3d.local.json', {}))

    def _launch(self, arguments, operation):
        if self.busy or self.state != 'IDLE':
            raise RuntimeError('Wait for confirmed STOP/exit before another operation')
        if not self.control:
            raise RuntimeError('Screen selftest: runtime commands disabled; use --control')
        if self.demo:
            self.note = 'DEMO only: ' + ' '.join(arguments)
            self.generation += 1
            return
        if os.name != 'posix':
            raise RuntimeError('Runtime control requires Linux process groups')
        if not (self.root/'soundsight-3d.sh').is_file():
            raise FileNotFoundError('Install screen into the existing SoundSight runtime root')
        # shell=False，参数不会解释为 shell 命令；新会话使 STOP 覆盖全部工作子进程。
        self.proc = subprocess.Popen(['sh', str(self.root/'soundsight-3d.sh')] + list(arguments),
                                     cwd=str(self.root), stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                     start_new_session=True, bufsize=0)
        self.pgid = self.proc.pid
        os.set_blocking(self.proc.stdout.fileno(), False)
        self.state, self.operation = 'RUNNING', operation
        self.note = 'Starting ' + operation
        self.started, self.pending = time.monotonic(), b''
        self.generation += 1

    def start(self, mode, axes):
        if mode not in ('SOUND', 'SPEAKER') or axes not in ('off', 'horizontal', 'vertical', 'both'):
            raise ValueError('Invalid mode or axis selection')
        if axes != 'off' and not self.motion:
            raise RuntimeError('Motion requires --enable-motion and explicit axis selection')
        args = ['follow-sound' if mode == 'SOUND' else 'speaker', '--axes', axes,
                '--frames', str(self.frames)]
        if mode == 'SPEAKER':
            args += ['--seconds', '30']
        self._launch(args, mode)

    def command(self, name, *values):
        # 配置写入交给原 CLI 校验及原子保存；切换用户沿用清除门限规则。
        if name not in ('speaker-select', 'speaker-list', 'speaker-config', 'level', 'filter', 'status'):
            raise ValueError('Unsupported screen command')
        self._launch([name] + [str(v) for v in values], name)

    def stop(self):
        if not self.busy:
            return
        if self.state != 'STOPPING':
            self.state, self.stopping = 'STOPPING', time.monotonic()
            self.note = 'STOP requested; waiting for process group exit'
            self.generation += 1
            try:
                os.killpg(self.pgid, signal.SIGINT)
            except ProcessLookupError:
                pass

    def _group_alive(self):
        try:
            os.killpg(self.pgid, 0)
            return True
        except ProcessLookupError:
            return False

    def tick(self):
        if not self.proc:
            return
        # 每轮最多读取 32 KiB，长行截断，避免日志洪流饿死 STOP/触摸循环。
        for _ in range(8):
            try:
                chunk = os.read(self.proc.stdout.fileno(), 4096)
            except BlockingIOError:
                break
            if not chunk:
                break
            self.pending += chunk
            while b'\n' in self.pending:
                line, self.pending = self.pending.split(b'\n', 1)
                self.lines.append(line[:800].decode('utf-8', errors='replace'))
                self.generation += 1
            if len(self.pending) > 8192:
                self.pending = self.pending[-800:]
        code = self.proc.poll()
        if code is not None:
            if self._group_alive():
                self.stop()
            else:
                self.proc.stdout.close()
                self.proc, self.pgid = None, None
                self.state = 'IDLE' if code == 0 else 'ERROR'
                self.note = 'Process group exited; return code %s' % code
                self.reload()
                self.generation += 1
                return
        # 配置/status 超时同样只发 SIGINT，不强杀或自动重新启动动作。
        if self.operation not in ('SOUND', 'SPEAKER') and time.monotonic()-self.started > 15:
            self.stop()
        if self.state == 'STOPPING' and time.monotonic()-self.stopping > 5:
            message = 'STOP UNCONFIRMED. No restart. Inspect terminal/hardware.'
            if self.note != message:
                self.note = message
                self.generation += 1

    def acknowledge(self):
        if not self.busy:
            self.reload()
            self.state = 'IDLE'
            self.note = 'Idle. Next START is explicit; axes must be reselected.'
            self.generation += 1
